<?php 
/**
 * @Copyright (C) 2015,
 * @Name  Base.class.php
 * @Author  yangw
 * @Version  Beta 1.0
 * @Date:  2015-6-4
 * @Description 接口基类
 * @Class Base
 */
namespace Api\Library;
class Base {
    protected $_url;
    protected $_host;
    protected $_download;
    public function __construct() {
        $this->_url = "http://".$_SERVER['HTTP_HOST']."/index.php/Api/";
        $this->_host = "http://".$_SERVER['HTTP_HOST'];
        $this->_download = "http://".$_SERVER['HTTP_HOST']."";   //下载地址域名
        $this->returnData();
    }

    /**
     * @desc 返回的数组
     * @param 
     * @return
     */
     protected function returnData() {
        $this->array10000 = array("status" => 1, "msg" => "请求成功！", "data" => null); 
        $this->array10004 = array("status" => 10004, "msg" => "参数不足！", "data" => null);
        $this->array10010 = array("status" => 10010, "msg" => "", "data" => null);
        //$this->array10001 = array("status" => 10001, "msg" => "参数不足！", "data" => null);

     }
    /**
     * @desc 获取链接信息
     * @param $url数据库中图片存储的信息
     * @param $type 1为  this->_host，  2为$this->_download
     * @return
     */
    protected function _get_url($url = '', $type = 1){
        $url = trim($url);
        if(!empty($url)) {
            if ($type == 1) {
                $url = $this->_host.$url;
            } else if ($type == 2) {
                $url = $this->_download.$url;
            }
        }
        return $url;
    }
    
    /**
     * @desc  连接多屏网关服务器接口
     * @param $userid 用户ID，盒子ID
     * @param $username 
     * @param $LoaclIP 本地IP
     * @param $serialnumber 设备标识，针对STB和一体机是必填，是指帖在盒子或一体机外面的标识  
     * @return
     */
    protected function periodic ($userid, $username, $LoaclIP, $serialnumber) {
        $curl = new \Api\Library\Curl();
        $url = "http://14.23.85.235:8081/service/periodic"; //注意后面不能后斜杠
        $contents = '{
            "reqhead":      {
                    "servicecode":  "OTTGW",
                    "distributor":  "SNM",
                    "clienttype":   "stb",
                    "clientid":     "JHSG7328f",
                    "clientver":    "1.0.1",
                    "devicetype":   "",
                    "clientos":     "andiod_4.3.1"
            },
            "reqbody":      {
                    "userid":       "'.$userid.'",
                    "username":     "'.$username.'",
                    "LoaclIP":      "'.$LoaclIP.'",
                    "model":        0,
                    "serialnumber": "'.$serialnumber.'"
            }
        }';
        $contents = trim($contents);
        return $curl->post($url, $contents);
    }
    /**
     * @desc  消息转发接口
     * @param $userid 用户ID，盒子ID
     * @return
     */
    protected function transpond ($userid, $username, $LoaclIP, $serialnumber) {
        $curl = new \Api\Library\Curl();
        $url = "http://14.23.85.235:8081/service/transpond"; //注意后面不能后斜杠
        //
        $contents = '{
            "reqhead":{
                "servicecode":"OTTGW",
                "distributor":"SNM",
                "clienttype":"pc",
                "clientid":"external system",
                "clientver":"",
                "devicetype":"",
                "clientos":""
            }, 
            "reqbody":{
                "duserid":"443",
                "model":0,
                "infotype":"1001",
                "information": "operation1:test operation."
            }
        }';
        $contents = trim($contents);
        return $curl->post($url, $contents);
    }
    /**
     * @desc  SimpleXMLElement 对象转换为 PHP 数组
     * @param $xml 对象
     * @return
     */
    protected function xmlToArr ($xml, $root = true) {
        if (!$xml->children()) { 
            return (string) $xml; 
        } 
        $array = array(); 
        foreach ($xml->children() as $element => $node) { 
            $totalElement = count($xml->{$element}); 
            if (!isset($array[$element])) { 
                $array[$element] = ""; 
            } 
            // Has attributes 
            if ($attributes = $node->attributes()) { 
                $data = array( 
                    'attributes' => array(), 
                    'value' => (count($node) > 0) ? $this->xmlToArr($node, false) : (string) $node 
                ); 
                foreach ($attributes as $attr => $value) { 
                    $data['attributes'][$attr] = (string) $value; 
                } 
                if ($totalElement > 1) { 
                    $array[$element][] = $data; 
                } else { 
                 $array[$element] = $data; 
                } 
            // Just a value 
            } else { 
                if ($totalElement > 1) { 
                    $array[$element][] = $this->xmlToArr($node, false); 
                } else { 
                    $array[$element] = $this->xmlToArr($node, false); 
                } 
            } 
        } 
        if ($root) { 
            return array($xml->getName() => $array); 
        } else { 
            return $array; 
        } 
    }
    
    /**
     * @desc 判断是否以HTTP开头的网址
     * @param 
     * @return
     */
    protected function isurl($url) {
        $http=  substr($url, 0,4);
        if($http=="http"){
            return 1;
        }else{
            return -1;
        }
    }
    
    
}

