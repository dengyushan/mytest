<?php 
/**
 * @Copyright (C) 2015,
 * @Name  Tc.class.php
 * @Author  dengyushan
 * @Version  Beta 1.0
 * @Date:  2016-02-26
 * @Description TV端弹窗接口类
 */

namespace Api\Library;
use Api\Library\Base;
class Tc extends Base{
    function __construct() {
        parent::__construct();
    }
	
    /**
     * @desc 微信相册弹窗
     */
	public function xt(){
		$return = $this->array10000;
		$return['data']['tc'] = 0;
		$return['data']['time'] = 3*60;
		$return['data']['title'] = '如何成为学霸？';
		$return['data']['picture_xc'] = 'http://weixin.yunfuntv.com/Public/System/picture_xc.png';
		$return['data']['picture_xt'] = 'http://weixin.yunfuntv.com/Public/System/picture_xt.png';
		$return['data']['downlink'] = 'http://app.yunfuntv.com/Public/Upload/Apk/57bd23ba270ef.apk';
		return $return;
	}
	
	/**
	 * @desc 微信相册应用更新
	 */
	public function update(){
		$return = $this->array10000;
		$return['data']['downlink'] = 'http://weixin.yunfuntv.com/Public/System/apk/yunfanggallery_Admin_20160831_VV1.1.1_release.apk';
		$return['data']['number'] = '20160831';
		$return['data']['name'] = '1.1.1';
		return $return;
	}
	
}