<?php 
/**
 * @Copyright (C) 2015,
 * @Name  Tvdevice.class.php
 * @Author  dengyushan
 * @Version  Beta 1.0
 * @Date:  2016-02-26
 * @Description TV端接口类
 * @Class Content
 */

namespace Api\Library;
use Api\Library\Base;
use \Think\Crypt\Driver\Think;
class Tvdevice extends Base{
    protected $Relation;
    protected $Picture;
    function __construct() {
        parent::__construct();
        $this->Relation = new \Common\Model\RelationModel();
        $this->Picture = new \Common\Model\PictureModel();
    }
    
    /**
     * @desc 获取二维码 
     * @param $mac
     */ 
    public function getQrcode( $data = array() ){
		if(isset($data['mac'])){
			$bind = $this->Relation->isBind( $data['mac'] );
			if($bind){
				//已经绑定，直接查出二维码地址
				$qrcode = $this->Relation->getQrcodePath( $data['mac'] );
				$return = $this->array10000;
				$return['data']['qrcode'] = $qrcode;
			}else{
				//尚未绑定，先绑定
				$deviceid = $this->Relation->linkDeviceid();
				//没有更多的二维码进行绑定，则自动生成一批二维码
				if(!$deviceid){
					//实例化weixin控制器
					$weixinObject = A('Api/Weixin');
					$weixinObject->newAuthorization();
					//重新绑定
					$deviceid = $this->Relation->linkDeviceid();
				}		
				//保存mac与deviceid 的关系
				$this->Relation->saveData( $deviceid,$data['mac'] );
				//获取二维码地址
				$qrcode = $this->Relation->getQrcodePath( $data['mac'] );
				$return = $this->array10000;
				$return['data']['qrcode'] = $qrcode;
			}
		}else{
			$return = $this->array10004;
		}
		return $return;
    }
    
    /**
     * @desc 获取图片
     * @param $mac 
     */
    public function getPicture( $data = array() ){
    	if(isset($data['mac'])){
    		//查出关联的deviceid
    		$deviceid = $this->Relation->getDeviceid( $data['mac'] );
    		if( $deviceid ){
    			$list = $this->Picture->getPicture( $deviceid );
    			if( count($list)>0 ){
    				$return = $this->array10000;
    				$return['data']['list'] = $list;
    			}else{
    				$return = $this->array10010;
    				$return['msg'] = '没有相关数据！';
    			}
    		}else{
    			$return = $this->array10010;
    			$return['msg'] = '未绑定deviceid！';
    		}
    	}else{
    		$return = $this->array10004;
    	}
    	return $return;
    }
    
    
    /**
     * @desc 删除图片
     * @param $pid
     */
    public function delPic( $data = array() ){
    	if(isset($data['pid'])){
    		$picture = $this->Picture->where("pid = {$data['pid']}")->getField('picture');
    		$_t = $this->Picture->delPicModel($data['pid']);
    		if($_t){
    			$return = $this->array10000;
    			//删除图片资源
    			$picture = str_replace('http://weixin.yunfuntv.com', '.', $picture);
    			@unlink($picture);
    		}else{
    			$return = $this->array10010;
    			$return['msg'] = '删除失败！';
    		}
    	}else{
    		$return = $this->array10004;
    	}
    	return $return;
    }
    
    
    
    
    
    
    
    
    
    
    
}