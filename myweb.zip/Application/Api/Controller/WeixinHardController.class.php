<?php
/**
 * @Copyright (C) 2016,
 * @Name  WeixinHardController.class.php
 * @Author  dengyushan
 * @Version  Beta 1.0
 * @Date:  2016-02-01
 * @Description Api管理控制器
 * @Class WeixinHardController
 */
namespace Api\Controller;
use Think\Controller;
class WeixinHardController extends Controller {
    public function __construct(){
        parent::__construct();
    }

    /**
     * 微信硬件平台api入口
     */
    public function index(){
    	//服务器配置验证时调用
    	$this->valid();
    	//自定义菜单
    	//$this->createMenu();
    	//处理并回复用户发送过来的消息时调用
    	//$this->responseMsg();
    }
  
    /**
     * 服务器配置验证
     */
    public function valid(){
    	$echostr = $_GET['echostr'];
    	if($this->checkSignature()){
    		echo $echostr;
    		exit;
    	}
    }
    /**
     * 检验signature
     */
    public function checkSignature(){
    	$signature = $_GET["signature"];
    	$timestamp = $_GET["timestamp"];
    	$nonce = $_GET["nonce"];
    	$token = C('WEIXIN_TOKEN');
    	$tmpArr = array($token, $timestamp, $nonce);
    	sort($tmpArr, SORT_STRING);
    	$tmpStr = implode( $tmpArr );
    	$tmpStr = sha1( $tmpStr );
    	if( $tmpStr == $signature ){
    		return true;
    	}else{
    		return false;
    	}
    }



}