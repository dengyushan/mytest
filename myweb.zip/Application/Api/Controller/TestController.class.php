<?php
/**
 * @Copyright (C) 2015,
 * @Name  TestController.class.php
 * @Author  dengyushan
 * @Version  Beta 1.0
 * @Date:  2015-6-2
 * @Description Api管理控制器
 * @Class TestController
 */
namespace Api\Controller;
use Think\Controller;
use Api\Controller\WeixinController;

class TestController extends WeixinController {
	protected $client;
	protected $appKey = '405048b7c354bccbc027756e';
	protected $masterSecret = '9a88413f9182a0447e38f40b';
	protected $insert;
    public function __construct(){
    	$this->client  = new \Common\Library\JPush\JPush($this->appKey,$this->masterSecret);
    	parent::__construct(); 
    	$this->insert = new \Common\Model\TestModel();
    }
    
    
   	public function index(){
//    		echo $this->insert->getLastSql();
//    		exit;
		echo 'test';exit;
		set_time_limit(600); 
		G('start');
   		for($i = 0;$i<=10000;$i++){
   			$data = array();
   			$data['num'] = 10;
   			$data['content'] = '【“驾驭出众”一汽-大众华博瑞祥泰邀您共赴全新一代迈腾驾享之旅活动嘉宾火热招募中！】进店购车即享7重惊喜！详询【4008-682-703】 到店购买宝来： 【1】现金直降14000元，综合优惠高达3.5万元（包含置换补贴、装饰）限时抢购！共 6台特价车，售完为止！（仅限网络VIP客户！到店找市场部领取定制礼品，1.6以下可享受国家购置税减半政策； 【2】置换购车-享补贴：8000元，【3】0利息分期-购车享7000-10000元 【4】购车享延保特惠，用车无忧【5】全新一代迈腾已到 店等您来赏';
   			$data['date'] = '2016-10-20';
   			$data['time'] = 1459927663;
   			$data['status'] = 1;
   			$this->insert->add($data);
   			//$this->Test->find();
   		}
   		G('end');
   		echo G('start','end',6);
   		exit;
   	}
    
   	public function delData(){
   		$m=M('user');
   		$m1=M('user_detail');
   		$m->startTrans();
   		$map['id']=1;
   		$res=$m->where($map)->delete();
   		$res1=$m1->delete();
   		if($res && $res1){
   			$m->commit();
   		}else{
   			$m->rollback();
   		}
   	
   	}
   	
    public function weixinTest(){
    	$this->createMenu();
    }
    
    public function cleanAllBind( $openid = 'oXnaiv53HJyGEbsy7QwkH-4pQG28' ){
    	$deviceid = $this->getDeviceid( $openid );
    	//解绑设备
    	$response = $this->unwrap( $deviceid,$openid );
    	dump($response);
    	exit;
    	//改变此用户上传过此设备的所有图片状态
    	M('picture')->where(" deviceid = '$deviceid' and openid = '$openid' and care = 1 and isdel = 0")->setField('care',0);
    	$response = json_to_array($response);
    	if( $response['base_resp']['errcode'] === 0 ){
    		$deviceid = $this->getDeviceid( $openid );
    		if($deviceid){
    			$this->cleanAllBind( $openid );
    		}
    	}
    }
    
    public function unwrap( $deviceid,$openid ){
    	$token = $this->getToken();
    	$url = 'https://api.weixin.qq.com/device/compel_unbind?access_token='.$token;
    	$json_data = '{
			    "device_id":'.'"'.$deviceid.'"'.', 
			    "openid":'.'"'.$openid.'"'.'
			}';
    	$response = api_post($url, $json_data);
    	return $response;
    }
    
    
    /**
     * @desc 对标记用户即时发送
     * @param $object 发送对象
     * @param $content 发送内容
     */
    public function tagsPush($object = array('B83D4E856F64'),$content = '测试成功',$title = 'test',$val_arr = array("jpush_type"=>"3","type"=>"4")){
    	$result = $this->client->push()
    	//->setPlatform(array('android','ios'))
    	->setPlatform(array('android'))
    	->addAlias($object)
    	->addTag(array())
    	->setNotificationAlert('')
    	//$val_arr = array("key1"=>"value1", "key2"=>"value2");
    	->addAndroidNotification($content,$title, 1,$val_arr)
    	//->addIosNotification("Hi, iOS notification", 'iOS sound', JPush::DISABLE_BADGE, true, 'iOS category', array("key1"=>"value1", "key2"=>"value2"))
    	->setMessage("msg content", 'msg title', 'type', array("key1"=>"value1", "key2"=>"value2"))
    	->setOptions(100000, 3600, null, false)
    	->send();
    	//echo 'Result=' . json_encode($result) . $br;
    }
    
    
    public function Jpush( ){
    	$Jpush = new \Common\Library\ORG\Util\Jpush();
    	$title = 'haha';
    	$backData = $Jpush->push($receiver='all', $title,'B8-3D-4E-85-6F-64',$m_type='',$m_txt='',$m_time=600);
    	dump($backData);
    	return $backData;
    }
    
    
    /**
     * @desc 根据openid 获取deviceid
     * @param 用户id
     */
    public function getDeviceid( $openid = 'oXnaiv9umrYI3jfgKRF5ux0VGS3c' ){//oXnaivx-wZ7QIsdVXPlzhmJQ_ATI
    	$token = $this->getToken();
    	$url = 'https://api.weixin.qq.com/device/get_bind_device?access_token='.$token.'&openid='.$openid;
    	$response = api_get($url);
    	$response = json_to_array($response);
    	echo  $response['device_list'][0]['device_id'];
    }
    
    public function test(){
    	$token = $this->getToken();
    	$MediaId = '90Ory-aWoszHrNr7jF8sfLjf_Pq8yebBp3Kie9B9N056dEnXh9-n4CUZzF5jj0S9';
    	//https://api.weixin.qq.com/cgi-bin/media/get?access_token=ACCESS_TOKEN&media_id=MEDIA_ID
    	$url = 'http://file.api.weixin.qq.com/cgi-bin/media/get?access_token='.$token.'&media_id='.$MediaId;
    	$result = api_get($url);
    	//dump($result);exit;
    	file_put_contents('2.jpg', $result );
    }
    
    /**
     * @desc 获取token
     */
    private function getToken(){
    	$appid = C('WEIXIN_APPID');
    	$secret = C('WEIXIN_APPSECRET');
    	$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$secret;
    	$response = api_get($url);
    	$response = json_to_array($response);
    	return $response['access_token'];
    }
    
    
    
    /**
     * @desc 接口的测试
     * @param 
     * @return 
     */
	 public function phpmailerAction($v){ 	
		 require_once("./Application/Common/Library/ORG/PHPMailer/class.phpmailer.php"); 
		 require_once("./Application/Common/Library/ORG/PHPMailer/class.smtp.php");  
		 $mail = new \Common\Library\ORG\PHPMailer\PHPMailer();	
		 // 设置PHPMailer使用SMTP服务器发送Email
		 $mail->IsSMTP();
		
		 // 设置邮件的字符编码，若不指定，则为'UTF-8'
		 //$mail->CharSet='gb2312';
		 //$arr = array('648031867@qq.com','957651598@qq.com');
		 // 添加收件人地址，可以多次使用来添加多个收件人
		 $mail->AddAddress($v);
		
		 // 设置邮件正文
		 $message='<B>这是一封测试邮件</B>';
		 $mail->Body=$message;
		 // 设置邮件头的From字段。
		 // 对于网易的SMTP服务，这部分必须和你的实际账号相同，否则会验证出错。
		 $mail->From='noreply@yunfuntv.com';
		
		 // 设置发件人名字
		 $mail->FromName='dengyushan';
		
		 // 设置邮件标题
		 $mail->Subject='邮件测试';
		
		 // 设置SMTP服务器。这里使用网易的SMTP服务器。
		 $mail->Host='yunfuntv.com';
		
		 // 设置为“需要验证”
		 $mail->SMTPAuth=true;
		
		 // 设置用户名和密码，即网易邮件的用户名和密码。
		 $mail->Username='noreply@yunfuntv.com';
		 $mail->Password='cyf123456';
		
		 // 发送邮件。
		 return $result = $mail->Send();		
	}
	function sentAction(){
		// 发送邮件。
		 $error = array();
		 $arr=array(1=>'957651598@qq.com',2=>'648031867@qq.com',3=>'dengyushan251314@163.com');
		 foreach($arr as $k=>$v){
			 $result = $this->phpmailerAction($v);
			 var_dump($result);
			 if(!$result){
				$error[] = $k;
			 }
		 }
		 print_r($error);
	}
	
	public function sentMailThink(){

		include("./Application/Common/Library/ORG/Util/class.phpmailer.php");
		include("./Application/Common/Library/ORG/Util/class.smtp.php");
		//获取一个外部文件的内容
		$mail             = new \Common\Library\ORG\Util\PHPMailer();
		$body             = file_get_contents('contents.html');
		$body             = eregi_replace("[]",'',$body);
		//设置smtp参数
		$mail->IsSMTP();
		$mail->SMTPAuth   = true;
		$mail->SMTPKeepAlive = true;
		$mail->SMTPSecure = "ssl";
		$mail->Host       = "smtp.163.com";
		$mail->Port       = 465;
		//填写你的gmail账号和密码
		$mail->Username   = "dengyushan251314@163.com";
		$mail->Password   = "cyf123456";
		//设置发送方，最好不要伪造地址
		$mail->From       = "dengyushan251314@163.com";
		$mail->FromName   = "Webmaster";
		$mail->Subject    = "This is the subject";
		$mail->AltBody    = $body;
		$mail->WordWrap   = 50; // set word wrap
		$mail->MsgHTML($body);
		//设置回复地址
		$mail->AddReplyTo("noreply@yunfuntv.com","Webmaster");
		//添加附件，此处附件与脚(www.phpfensi.com)本位于相同目录下
		//否则填写完整路径
		$mail->AddAttachment("attachment.jpg");
		$mail->AddAttachment("attachment.zip");
		//设置邮件接收方的邮箱和姓名
		$mail->AddAddress("95765159@qq.com","FirstName LastName");
		//使用HTML格式发送邮件
		$mail->IsHTML(true);
		//通过Send方法发送邮件
		//根据发送结果做相应处理
		if(!$mail->Send()) {
			echo "Mailer Error: " . $mail->ErrorInfo;
		} else {
			echo "Message has been sent";
		}
		
	}
	
	

}