<?php
namespace Api\Controller;
use Think\Controller;
class DemoController extends Controller {
	public function mail(){
// 		$email = 'dengyushan251314@163.com';
// 		$code = '654321';
// 		sentMail( $email,$code );
// 		exit;
		require_once("./Application/Common/Library/ORG/PHPMailer/class.phpmailer.php");
		require_once("./Application/Common/Library/ORG/PHPMailer/class.smtp.php");
		 $mail = new \PHPMailer();
		 $mail->IsSMTP ();
		 // SMTP 邮件服务器地址，这里需要替换为发送邮件的邮箱所在的邮件服务器地址
		 $mail->Host ='smtp.yunfuntv.com';      //$siteMail['mail']['host'];
		 //$mail->Port = 25;
		 //邮件服务器验证开
		 $mail->SMTPAuth = true;
		 // SMTP服务器上此邮箱的用户名，有的只需要@前面的部分，有的需要全名。请替换为正确的邮箱用户名
		 $mail->Username ="noreply@yunfuntv.com"; //$siteMail['mail']['email'];
		 // SMTP服务器上该邮箱的密码，请替换为正确的密码
		 $mail->Password ="cyf123456"; //$siteMail['mail']['password'];
		 // SMTP服务器上发送此邮件的邮箱，请替换为正确的邮箱  ,与$mail->Username 的值是对应的。
		 $mail->From = "noreply@yunfuntv.com";//$siteMail['mail']['username'];
		 // 真实发件人的姓名等信息，这里根据需要填写
		 $mail->FromName ="admin"; //$siteMail['mail']['name'];
		 // 这里指定字符集！
		 $mail->CharSet = "utf-8";
		 //$mail->Encoding = 'base64';
		 // 收件人邮箱和姓名
		 $mail->AddAddress("dengyushan251314@163.com");//dengyushan251314@163.com
		 // 发送 HTML邮件
		 $mail->IsHTML(true);
		 // 邮件主题
		 $mail->Subject ="你好"; //$emailType['emailSubject'];
		 // 邮件内容
		 $body = '<p>Dear User,</p>';
		 $body.= '<p>Selamat Datang ke Nutizen!</p>';
		 $body.= '<p>Terima kasih telah mendaftar dengan kami. </p>';
		 $body.= '<p>Username kamu: < <font color="red"><b>957651598@qq.com</b></font> ></p>';
		 $body.= '<p>Activation Code:< <font color="red"><b>789456</b></font> ></p>';
		 $mail->Body = $body;
		 //$mail->AltBody = "text/html";
		 var_dump($mail->Send());
		 if (!$mail->Send()) {
		 } else {
		 	$status = true;
		 }
	}
	
// 	名：dengyushan251314@163.com
// 	密：251314
	
// 	$mail->Username='noreply@yunfuntv.com';
// 	$mail->Password='cyf123456';
	
// 	$mail->Username ="15895914244@163.com"; //$siteMail['mail']['email'];
// 	// SMTP服务器上该邮箱的密码，请替换为正确的密码
// 	$mail->Password ="8309024314"; //$siteMail['mail']['password'];
// 	// SMTP服务器上发送此邮件的邮箱，请替换为正确的邮箱  ,与$mail->Username 的值是对应的。
// 	$mail->From = "15895914244@163.com";//$siteMail['mail']['username'];
}