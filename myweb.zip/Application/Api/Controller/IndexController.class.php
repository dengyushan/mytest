<?php
/**
 * @Copyright (C) 2015,
 * @Name  IndexController.class.php
 * @Author  dengyushan
 * @Version  Beta 1.0
 * @Date:  2015-6-2
 * @Description Api管理控制器
 * @Class IndexController
 */
namespace Api\Controller;
use Think\Controller;

class IndexController extends Controller {
    
    private $iv = '&cvs$%69988dDWkq'; //Same as in JAVA  
    private $key = '*7j-_12mfdeKH@f,'; //Same as in JAVA  
    private $sercet_key = "cyf@#2016Weixin"; //秘钥//
    private $key_value = '285e6fbc113eafce0018537034323a1c';
    public function __construct(){
        parent::__construct();
    }
    
    
    /**
     * @desc 接口的测试
     * @param 
     * @return 
     */
    public function test(){
    	//$this->api_address = 'http://api.nu.local/index.php/Index/index';
    	$this->display();
    	echo '<div style="clear:both;"></div>';
    	echo '<br/>';
    	
    	echo '获取二维码'.'<br/>';
    	echo 'class：Tvdevice'.'<br/>';
    	echo 'function:getQrcode'.'<br/>';
    	$options['mac'] = 'abcdefghijklmn123';
    	echo json_encode($options,JSON_UNESCAPED_UNICODE);echo '<br/>';
    	unset($options);
    	$options['key'] = $this->key_value;
    	$options['class'] = 'Tvdevice';
    	$options['function'] = 'getQrcode';
    	$options['data']['mac'] = 'abcdefghijklmn123';
    	echo json_encode($options,JSON_UNESCAPED_UNICODE);echo '<br/>';
    	unset($options);
    	echo '<br/>';echo '<br/>';
    	
    	
    	echo '获取图片'.'<br/>';
    	echo 'class:Tvdevice'.'<br/>';
    	echo 'function:getPicture'.'<br/>';
    	$options['mac'] = 'abcdefghijklmn123';
    	echo json_encode($options,JSON_UNESCAPED_UNICODE);echo '<br/>';
    	unset($options);
    	$options['key'] = $this->key_value;
    	$options['class'] = 'Tvdevice';
    	$options['function'] = 'getPicture';
    	$options['data']['mac'] = 'abcdefghijklmn123';
    	echo json_encode($options,JSON_UNESCAPED_UNICODE);echo '<br/>';
    	unset($options);
    	echo '<br/>';echo '<br/>';
   
    	
    	echo '删除图片'.'<br/>';
    	echo 'class:Tvdevice'.'<br/>';
    	echo 'function:delPic'.'<br/>';
    	$options['pid'] = 1;
    	echo json_encode($options,JSON_UNESCAPED_UNICODE);echo '<br/>';
    	unset($options);
    	$options['key'] = $this->key_value;
    	$options['class'] = 'Tvdevice';
    	$options['function'] = 'delPic';
    	$options['data']['pid'] = 1;
    	echo json_encode($options,JSON_UNESCAPED_UNICODE);echo '<br/>';
    	unset($options);
    	echo '<br/>';echo '<br/>';
    	
    	echo '获取弹窗标题'.'<br/>';
    	echo 'class:Tc'.'<br/>';
    	echo 'function:title'.'<br/>';
    	echo json_encode($options,JSON_UNESCAPED_UNICODE);echo '<br/>';
    	unset($options);
    	$options['key'] = $this->key_value;
    	$options['class'] = 'Tc';
    	$options['function'] = 'title';
    	echo json_encode($options,JSON_UNESCAPED_UNICODE);echo '<br/>';
    	unset($options);
    	echo '<br/>';echo '<br/>';
    	
    	echo '获取内容与下载链接'.'<br/>';
    	echo 'class:Tc'.'<br/>';
    	echo 'function:xt'.'<br/>';
    	echo json_encode($options,JSON_UNESCAPED_UNICODE);echo '<br/>';
    	unset($options);
    	$options['key'] = $this->key_value;
    	$options['class'] = 'Tc';
    	$options['function'] = 'xt';
    	echo json_encode($options,JSON_UNESCAPED_UNICODE);echo '<br/>';
    	unset($options);
    	echo '<br/>';echo '<br/>';
    }
    

    
    /**
     * @desc 入口函数
     * @param 
     * @return
     */
    public function index(){
        $key = I("request.key");//加密过后的数据
        $class = trim(I("request.class")); //类名
        $function = trim(I("request.function")); //方法名
        $data =  trim(I("request.data")); //参数，JSON字符串
        $decrypt_key = $this->decrypt($key); //解密 
        $return = array();
        if ($decrypt_key != $this->sercet_key) { //判断解密后是否与秘钥匹配
            $return = array("status" => 10001, "msg" => "参数key错误", "data" => "");
        } else {
            $dir = str_replace("Controller", "Library", __DIR__);
            $file = $dir."\\".$class.".class.php";
            $file = str_replace("\\", "/", $file);
            if (!file_exists($file)) { //判断该类是否存在
                $return = array("status" => 10002, "msg" => "参数Class错误", "data" => "");
            } else {
                $class = "\Api\Library\\".$class;
                $obj = new $class();
                if(!method_exists($class, $function)){
                    $return = array("status" => 10003, "msg" => "参数function错误", "data" => "");
                } else {
                    $data = str_replace("&quot;", "\"", $data);
                    $data = str_replace("\\", "", $data);
                        $data = json_decode($data, true);
                        $data['key'] = $key;
                        $return = $obj->$function($data);
                }
            }
        }
        echo json_encode($return);exit;
    }

    /**
     * @desc 加密
     * @param string
     * @return string
     */
    function encrypt($str) {      
        $iv = $this->iv;  
        $td = mcrypt_module_open('rijndael-128', '', 'cbc', $iv);  
        mcrypt_generic_init($td, $this->key, $iv);  
        $encrypted = mcrypt_generic($td, $str);  
        mcrypt_generic_deinit($td);  
        mcrypt_module_close($td);  
        return bin2hex($encrypted);  
    }  
     /**
     * @desc 解密
     * @param string
     * @return string
     */
    function decrypt($code) {  
        $code = $this->hex2bin($code);  
        $iv = $this->iv;  
        $td = mcrypt_module_open('rijndael-128', '', 'cbc', $iv);  
        mcrypt_generic_init($td, $this->key, $iv);  
        $decrypted = mdecrypt_generic($td, $code);  
        mcrypt_generic_deinit($td);  
        mcrypt_module_close($td);  
        return utf8_encode(trim($decrypted));  
    } 
    protected function hex2bin($hexdata) {  
        $bindata = '';  
        for ($i = 0; $i < strlen($hexdata); $i += 2) {  
              $bindata .= chr(hexdec(substr($hexdata, $i, 2)));  
        }  
        return $bindata;  
    }
    
}