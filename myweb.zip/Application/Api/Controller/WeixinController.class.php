<?php
/**
 * @Copyright (C) 2016,
 * @Name  WeixinController.class.php
 * @Author  dengyushan
 * @Version  Beta 1.0
 * @Date:  2016-02-01
 * @Description Api管理控制器
 * @Class WeixinController
 */
namespace Api\Controller;
use Think\Controller;
class WeixinController extends Controller {
	protected $Relation;
	protected $client;
	protected $appKey = '405048b7c354bccbc027756e';
	protected $masterSecret = '9a88413f9182a0447e38f40b';
    public function __construct(){
    	$this->Relation = new \Common\Model\RelationModel();
    	$this->client  = new \Common\Library\JPush\JPush($this->appKey,$this->masterSecret);
        parent::__construct();
    }
    
    /** 
	微信目前提供了五种消息类型，分别为：
	文本消息（text）；
	图片消息（image）；
	地理位置消息（location）；
	链接消息（link）；
	事件推送（event）；
     */
    
    /**
     * @desc 微信api入口
     */
    public function index(){
    	//服务器配置验证时调用
    	//$this->valid();
    	//自定义菜单
     	//$this->createMenu();
    	//下载临时多媒体图片
    	//$this->downLoad();
    	//处理并回复用户发送过来的消息时调用
    	$this->responseMsg();	
    	//设备授权（旧）
    	//$this->authorization();
    	//设备授权（新方法）
    	//$this->newAuthorization();
    	//获取用户当前绑定的设备id
    	//$this->getDeviceid( $openid = 'oXnaiv4gbOR9zlRytqwGVsuK0cr8' );
    	//获取二维码
    	//$this->getBarcode();
    	//更新已授权的设备属性值
    	//$this->updateAttribute( $device_id );
    	//$openid = 'oXnaiv4gbOR9zlRytqwGVsuK0cr8';
    	//$deviceid = 'gh_93f84988f39e_572ecd110f7ff0a0';
    	//解绑设备
    	//$this->unwrap( $deviceid,$openid );                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
    	//绑定设备
    	//$this->forceBind( $deviceid,$openid );
    	//清除用户的所有绑定
    	//$this->cleanAllBind( $openid );
    	//获取用户信息
    	//$this->getUserInfo();
    	//极光推送
    	//$this->Jpush('gh_93f84988f39e_b219b999f74935cf');
    }
  
    
    /**
     * @desc 服务器配置验证
     */
    private function valid(){
    	$echostr = $_GET['echostr'];
    	if($this->checkSignature()){
    		echo $echostr;
    		exit;
    	}
    }
    
    /**
     * @desc 检验signature
     */
    private function checkSignature(){
    	$signature = $_GET["signature"];
    	$timestamp = $_GET["timestamp"];
    	$nonce = $_GET["nonce"];
    	$token = C('WEIXIN_TOKEN');
    	$tmpArr = array($token, $timestamp, $nonce);
    	sort($tmpArr, SORT_STRING);
    	$tmpStr = implode( $tmpArr );
    	$tmpStr = sha1( $tmpStr );
    	if( $tmpStr == $signature ){
    		return true;
    	}else{
    		return false;
    	}
    }
    
    /**
     * @desc 获取用户消息
     */
    private function responseMsg(){
    	//接收微信公众平台发送过来的用户消息，该消息数据结构为XML，不是php默认的识别数据类型，
    	//因此这里用了$GLOBALS['HTTP_RAW_POST_DATA']来接收，同时赋值给了$postStr
    	//$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];//设置了register_globals禁止则用不了
    	$postStr = file_get_contents("php://input");
    	if (!empty($postStr)){
    		//使用simplexml_load_string() 函数将接收到的XML消息数据载入对象$postObj中
    		$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
//     		for($i=1;$i<16;$i++){
//     			unlink("$i.txt");
//     		} 
    		$RX_TYPE = trim($postObj->MsgType);
    		switch($RX_TYPE){
    			case "text":
    				//使用handleText() 函数处理文本消息；
    				$resultStr = $this->handleText($postObj);
    				break;
    			case "event":
    				//使用handleEvent() 函数处理事件推送；
    				$resultStr = $this->handleEvent($postObj);
    				break;
    			case "image":
    				//图片上传事件
//     				if($postObj->FromUserName == 'oXnaiv9umrYI3jfgKRF5ux0VGS3c'){
//     					file_put_contents('4.txt',print_r($postObj,true),FILE_APPEND);
//     				}
    				$resultStr = $this->handPicture1($postObj);
    				break;
    			case "device_event":
    				//设备事件
    				$resultStr = $this->handleDeviceEvent($postObj);
    				break;
    			default:
    				$resultStr = "Unknow msg type: ".$RX_TYPE;
    			break;
    		}
    		echo $resultStr;
    	}else {	
    		echo "";	
    		exit;   	
    	}
    }
    
    /**
     * @desc 处理文本消息函数
     */
    private function handleText($postObj){
    	$fromUsername = $postObj->FromUserName;
    	$toUsername = $postObj->ToUserName;
    	$keyword = trim($postObj->Content);
    	$time = time();
    	$textTpl = "<xml>
					<ToUserName><![CDATA[%s]]></ToUserName>
					<FromUserName><![CDATA[%s]]></FromUserName>
					<CreateTime>%s</CreateTime>
					<MsgType><![CDATA[%s]]></MsgType>
					<Content><![CDATA[%s]]></Content>
					<FuncFlag>0</FuncFlag>
					</xml>";
    	if(!empty( $keyword )){
    		$msgType = "text";
    		//根据用户不同指令，回复不同的内容
    		if( $keyword == '你好' ){
    			$contentStr = "你也好！";
    		}else if( $keyword == '2016' ){
    			$contentStr = "祝你新年快乐！心想事成！";
    		}else if( $keyword == '图文' ){
    			$resultStr = $this->handPicture2($postObj);
    			echo $resultStr;
    			exit;
    		}else{
    			$contentStr = "您的问题我们已收到，如需加急处理请加客服QQ：3040678367";
    		}	
    		$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
    		echo $resultStr;
    	}else{
    		echo "Input something...";
    	}
    }
    
    /**
     * @desc 处理事件推送函数
     * @param 相关数据对像
     */
    private function handleEvent($object){
    	$contentStr = "";
    	$openid = $object->FromUserName;
    	switch ($object->Event){
    		//关注
    		case "subscribe":
    			$deviceid = $this->getDeviceid( $openid );
    			if($deviceid){
    				$contentStr = "恭喜您：设备绑定成功！";
    			}else{
    				$contentStr = "亲爱的用户，欢迎来到桔柚公众平台！";
    			}
    			break;
    		//取消关注（同时解绑用户曾绑定的所有设备）		
    		case "unsubscribe":	
    			//激光推送客户端取消关注
    			$device_id = $this->getDeviceid($object->FromUserName);
    			//清除绑定纪录
    			$this->cleanAllBind($object->FromUserName);
    			$mac_bf = $this->Relation->getMac($device_id);
    			$mac_af = str_replace('-', '', $mac_bf);
    			$message = "{\"mac\":\"$mac_bf\"}";
    			$response = $this->tagsPush(array($mac_af),$message,'解绑推送',$mac_bf);
    			break;
    		case "CLICK":
    			if($object->EventKey =='kefu'){
    				$contentStr = "有疑问？要吐槽？求教程？提建议？请和我们联系吧！"."\n"."桔柚学堂QQ群：140881280"."\n"."桔柚彩票QQ群：189138849"."\n"."桔柚云相册QQ群：563461428";
    			}else{
    				$contentStr = "请加客服QQ：140881280！";
    			}
    			break;
    		default :
    			$contentStr = "Unknow Event: ".$object->Event;
    			break;
    	}
    	$this->responseText($object, $contentStr);
    }
    
    
    /**
     * @desc 处理事件推送函数
     * @param 相关数据对像
     */
    private function handleDeviceEvent($object){
    	$contentStr = "";
    	switch ($object->Event){
    		case "bind":
    			$device_id = $object->DeviceID;
    			$openid = $object->FromUserName;
    			//清除所有绑定关系
    			$this->cleanAllBind($openid);
    			//强制绑定用户与设备关系
    			$response = $this->forceBind( $device_id,$openid);    			    
    			//恢复此用户上传的所有图片的状态
    			M('picture')->where(" deviceid = '$device_id' and openid = '$openid' and care = 0 and isdel = 0")->setField('care',1);
    			$mac_bf = $this->Relation->getMac($device_id);
    			$mac_af = str_replace('-', '', $mac_bf);
    			$message = "{\"mac\":\"$mac_bf\"}";
    			$response = $this->tagsPush(array($mac_af),$message,'绑定推送',$mac_bf);
    			break;
    		case "unbind";
    			break;
    	}
    }
    				 
    
    /**
     * @desc 返回文本内容
     * @param 相关数据对像
     * @param 内容
     */
    private function responseText($object, $content, $flag=0){
    	$textTpl = "<xml> 
		       <ToUserName><![CDATA[%s]]></ToUserName> 
		       <FromUserName><![CDATA[%s]]></FromUserName> 
		       <CreateTime>%s</CreateTime> 
		       <MsgType><![CDATA[text]]></MsgType> 
		       <Content><![CDATA[%s]]></Content> 
		       <FuncFlag>0</FuncFlag> 
		       </xml>"; 
    	$resultStr = sprintf($textTpl, $object->FromUserName, $object->ToUserName, time(), $content, $flag);
    	echo $resultStr;
    }
    
    /**
     * @desc 图片处理函数
     * @param  $object
     */
    private function handPicture1($object){  	
		$this->downLoad($object->MediaId,$object);
    }
    
    /**
     * @desc 返回图文消息
     * @param 
     */
    private function handPicture2($object){
    	 $content = array();
    	 $content[] = array("Title"=>"多图文标题1", "Description"=>"", "PicUrl"=>"http://img3.imgtn.bdimg.com/it/u=152530269,2172741570&fm=21&gp=0.jpg", "Url" =>"https://www.baidu.com/");
    	 $content[] = array("Title"=>"多图文标题2", "Description"=>"", "PicUrl"=>"http://img2.imgtn.bdimg.com/it/u=2865141976,2945240306&fm=23&gp=0.jpg", "Url" =>"https://www.baidu.com/");
    	 $content[] = array("Title"=>"多图文标题3", "Description"=>"", "PicUrl"=>"http://img4.imgtn.bdimg.com/it/u=3146951010,3971266286&fm=23&gp=0.jpg", "Url" =>"https://www.baidu.com/");
    	 if(is_array($content)){
    	 if (isset($content[0]['PicUrl'])){
    	 	$result = $this->transmitNews($object, $content);
    	 }else if (isset($content['MusicUrl'])){
    	 	$result = $this->transmitMusic($object, $content);
    	 }
    	 }else{
    	 	$result = $this->transmitText($object, $content);
    	 }
    	 return $result; 
    }
    
    /**
     * @desc 回复图文消息
     * @param $object 相关数据对像
     * @param $contArray 内容数组
     */	
    private function transmitNews($object, $contArray){
        if(!is_array($contArray)){
            return;
        }
        $itemTpl = "<item>
	        <Title><![CDATA[%s]]></Title>
	        <Description><![CDATA[%s]]></Description>
	        <PicUrl><![CDATA[%s]]></PicUrl>
	        <Url><![CDATA[%s]]></Url>
	    	</item>";
        $item_str = "";
        foreach ($contArray as $item){
            $item_str .= sprintf($itemTpl, $item['Title'], $item['Description'], $item['PicUrl'], $item['Url']);
        }
        $xmlTpl = "<xml>
			<ToUserName><![CDATA[%s]]></ToUserName>
			<FromUserName><![CDATA[%s]]></FromUserName>
			<CreateTime>%s</CreateTime>
			<MsgType><![CDATA[news]]></MsgType>
			<ArticleCount>%s</ArticleCount>
			<Articles>
			$item_str</Articles>
			</xml>";
        $resultStr = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), count($contArray));
        return  $resultStr; 
    }

     /**
      * @desc 从微信服务器下载图片到本地（永久保存）
      * 对于临时素材，每个素材（media_id）会在开发者上传或粉丝发送到微信服务器3天后自动删除（所以用户发送给开发者的素材，若开发者需要，应尽快下载到本地），以节省服务器资源。
      * @param $MediaId 媒体id
      * @param $object  相关对像数据
      */
     private function downLoad($MediaId,$object){
     	$token = $this->getToken();   	
     	$url = 'http://file.api.weixin.qq.com/cgi-bin/media/get?access_token='.$token.'&media_id='.$MediaId;
     	$result = api_get($url);
     	if(!is_dir(C('WEIXIN_PIC_PATH'))){
     		mkdir(C('WEIXIN_PIC_PATH'),0777,'recursive');//recursive 是递归生成目录
     	}
     	//通过openid获取用户绑定的deviceid
     	$device_id = $this->getDeviceid($object->FromUserName);
     	$write = $device_id."-----";
//      	if($object->FromUserName == 'oXnaiv9umrYI3jfgKRF5ux0VGS3c'){
//      		file_put_contents('3.txt',print_r($object,true),FILE_APPEND);
//      	}
     	if(!$device_id){//没有绑定设备上传图片
     		$this->responseText($object, $content = '未绑定设备，上传失败！', $flag=0);
     		exit;
     	}
     	$fileName = $device_id.'_'.substr(microtime(),17,4).substr(microtime(),6,4).'.jpg';     	   	
     	file_put_contents( C('WEIXIN_PIC_PATH').'/'.$fileName, $result );//如果要传到图片服务器，可以先用curl传字符串到图片服务器，然后再做以下处理
     	//获取用户信息
     	$userInfo = $this->getUserInfo($object->FromUserName);
     	//保存图片数据
     	$data = array();
     	$data['deviceid'] = $device_id;
     	$data['picture'] = C('WEBSET_URL').'/'.C('WEIXIN_PIC_PATH').'/'.$fileName;
     	$data['addtime'] = time();
     	$data['nickname'] = $userInfo['nickname'];
     	$data['headimgurl'] = $userInfo['headimgurl'];
     	$data['openid'] = "$object->FromUserName";
     	$data['mediaid'] = "$MediaId";//此字段是唯一的，为了去重而存在
     	M('picture')->add($data);
     	//极光推送消息给客户端(为了极光推送不堵塞正常流程，极光推送使用虚拟请求调用)
//      	$url = "http://weixin.yunfuntv.com/index.php/Api/Weixin/uploadJpush/device_id/".$device_id;
//      	$result = api_get($url);
     	$this->uploadJpush($device_id);
     	$this->responseText($object, $content = '图片上传成功', $flag=0);	
     }
         
     /**
      * @desc 图片上传极光推送
      */
     public function uploadJpush($device_id){
     	//$device_id = I('get.device_id');
     	$mac_bf = $this->Relation->getMac($device_id);
     	$mac_af = str_replace('-', '', $mac_bf);
     	$message = "{\"mac\":\"$mac_bf\"}";
     	$response = $this->tagsPush(array($mac_af),$message,'上传图片推送',$mac_bf);
     }
     
     /**
      *@desc 设备授权 （旧）
      */
     private function authorization(){
     	$auth_key = md5('cyf@wx#admin');//6f3ed0fc5e1795afd46d6b367a479532
     	$json_data = '{
     		"device_num":"1",
     		"device_list":[
     		{
     			"id":"yunfuntv_dev1",
     			"mac":"262565895ABC",
     			"connect_protocol":"1",
     			"auth_key":"6f3ed0fc5e1795afd46d6b367a479532",
     			"close_strategy":"1",
     			"conn_strategy":"1",
     			"crypt_method":"1",
     			"auth_ver":"1",
     			"manu_mac_pos":"-1",
     			"ser_mac_pos":"-2",
     			"ble_simple_protocol": "0"
     		}
     		],
     		"op_type":"0",
     		"product_id": "5909"
     	}';
     	$token = $this->getToken();
     	$url = 'https://api.weixin.qq.com/device/authorize_device?access_token='.$token;
     	$response = api_post($url,$json_data);
     	echo '<pre>';
     	print_r(json_to_array($response));
     	exit;
     }
     
     /**
      * @desc 设备授权(新方法)
      * @param $product_id 产品id
      * @param $number 授权数量
      */
     public function newAuthorization( ){
     	$number = 50;
     	$product_id = 5909;//产品id
     	$token = $this->getToken();
     	$cul = 'https://api.weixin.qq.com/device/getqrcode?access_token='.$token.'&product_id='.$product_id;
     	$device_id_arr = array();
     	for($i=1;$i<=$number;$i++){
	     	$response = api_get($cul);
	     	$res_arr = json_to_array($response);
	     	$device_id_arr[] = $res_arr['deviceid'];
     	}
     	//拼接$device_id_list 字符串
     	$device_id_list = '["';
     	foreach($device_id_arr as $key=>$val){
     		$device_id_list.= $val.'","';
     	}
     	$device_id_list = rtrim($device_id_list,',"');
     	$device_id_list = $device_id_list.'"]';
     	//获取二维码字符串
     	$this->getBarcode( count($device_id_arr),$device_id_list );
     }
     
     /**
      * @desc 绑定设备成功通知
      */
    private function bindMsg(){
    	$token = $this->getToken();
    	$cul = 'https://api.weixin.qq.com/device/bind?access_token='.$token;
    	$json_data = '{
			    "ticket": "TICKET", 
			    "device_id": "yunfuntv_dev1", 
			    "openid": " OPENID"
				}';
    	$response = api_post($url,$json_data);
    	echo '<pre>';
    	print_r(json_to_array($response));
    	exit;
    }
    
    /**
     * @desc 根据openid 获取deviceid
     * @param 用户id
     */
    private function getDeviceid( $openid ){
    	$token = $this->getToken();
    	$url = 'https://api.weixin.qq.com/device/get_bind_device?access_token='.$token.'&openid='.$openid;
    	$response = api_get($url);
    	$response = json_to_array($response);
    	return $response['device_list'][0]['device_id'];	
    }
    
    /**
     * @desc 获取设备二维码字符串列
     * @param 二维码个数
     * @param 二维码串列
     */
    private function getBarcode( $count,$device_id_list ){
    	$token = $this->getToken();
    	$url = 'https://api.weixin.qq.com/device/create_qrcode?access_token='.$token;
    	$json_data = '{
		    "device_num":'.$count.',
		    "device_id_list":'.$device_id_list.'
			}';
    	$response = api_post($url,$json_data);
    	$response = json_to_array($response);
    	$code_list = $response['code_list'];
    	//遍历生成二维码图片并保存到本地
    	foreach($code_list as $key=>$val){
    		$this->createBarcode($val['ticket'],$val['device_id']);
    	}
    }
    
    /**
     * @desc 生成二维码
     * @param $content 二维码内容
     * @param $device_id 设备id
     */
   private function createBarcode($content,$device_id) {
   		require_once("./Application/Common/Library/phpqrcode/phpqrcode.php");
   		$QRcode = new \QRcode();
    	//定义纠错级别
    	$errorLevel = "L";
    	//定义生成图片宽度和高度;默认为3
    	$size = 8;
    	//文件名
    	$fileName = $device_id.'.png';
    	//保存路径
    	$save_path = C('WEIXIN_QRCODE_PATH');
    	//不存在则创建路径
    	if(!is_dir($save_path)){
    		mkdir($save_path,0777,'recursive');//recursive 是递归生成目录
    	}
    	//添加参数
    	$content = $content.'#'.$device_id;
    	//调用QRcode类的静态方法png生成二维码图片
    	$QRcode->png($content ,$save_path.'/'.$fileName ,$errorLevel ,$size ,$margin = 4 ,$saveandprint=false);    	
    	//保存设备id与图片相关信息到数据库
    	$data = array(); 	 
    	$data['qrcode'] = C('WEBSET_URL').'/'.$save_path.'/'.$fileName;
    	$data['deviceid'] = $device_id;
    	$data['addtime'] = time();
    	M('relation')->add($data);
    }
    
    /**
     * @desc 利用device_id更新设备属性
     * @param $device_id 设备id
     */
    private function updateAttribute($device_id){
    	$token = $this->getToken();
    	$url = 'https://api.weixin.qq.com/device/authorize_device?access_token='.$token;
    	$json_data = '{
					    "device_num":"1",
					    "device_list":[
					        {
					            "id":'.'"'.$device_id.'"'.',
					            "mac":"262565895ABC",
					            "connect_protocol":"3",
					            "auth_key":"6f3ed0fc5e1795afd46d6b367a479532",
					            "close_strategy":"1",
					            "conn_strategy":"1",
					            "crypt_method":"1",
					            "auth_ver":"1",
					            "manu_mac_pos":"-1",
					            "ser_mac_pos":"-2",
					            "ble_simple_protocol": "0"
					        }
					    ],
					    "op_type":"1"
					  }';
    	$response = api_post($url, $json_data);
    	$response = json_to_array($response);
    	echo '<pre>';
    	print_r($response);
   		exit;
    	
    }
    
    /**
     * @desc 强制绑定用户和设备
     * @param $deviceid 设备id
     * @param $openid  用户id
     */
    private  function forceBind( $deviceid,$openid ){
    	$token = $this->getToken();
    	$url = 'https://api.weixin.qq.com/device/compel_bind?access_token='.$token;
    	$json_data = '{
			    "device_id":'.'"'.$deviceid.'"'.', 
			    "openid":'.'"'.$openid.'"'.'
			}';
    	$response = api_post($url, $json_data);
    	$response = json_to_array($response);
    	return $response;
    }
    
    /**
     * @desc 强制解绑用户和设备
     * @param $deviceid 设备id
     * @param $openid  用户id
     */
    private function unwrap( $deviceid,$openid ){
    	$token = $this->getToken();
    	$url = 'https://api.weixin.qq.com/device/compel_unbind?access_token='.$token;
    	$json_data = '{
			    "device_id":'.'"'.$deviceid.'"'.', 
			    "openid":'.'"'.$openid.'"'.'
			}';
    	$response = api_post($url, $json_data);
    	return $response;
    }

	/**
	 * @desc 解绑用户所有的绑定信息
	 * @param $openid
	 */
    private function cleanAllBind( $openid ){
    	$deviceid = $this->getDeviceid( $openid );
    	//解绑设备
    	$response = $this->unwrap( $deviceid,$openid );
    	//改变此用户上传过此设备的所有图片状态
    	M('picture')->where(" deviceid = '$deviceid' and openid = '$openid' and care = 1 and isdel = 0")->setField('care',0);
    	$response = json_to_array($response);
    	if( $response['base_resp']['errcode'] === 0 ){
    		$deviceid = $this->getDeviceid( $openid );
    		if($deviceid){
    			$this->cleanAllBind( $openid ); 
    		}
    	}
    }
    
    /**
     * @desc 获取用户信息
     * @param $openid 用户唯一标识  
     */
    private  function getUserInfo( $openid ){
    	$token = $this->getToken();
    	$url = 'https://api.weixin.qq.com/cgi-bin/user/info?access_token='.$token.'&openid='.$openid.'&lang=zh_CN';
    	$response = api_get($url);
    	$response = json_to_array($response);
    	return $response;
    }
    
    
	/**
	 * @desc 获取token
	 */ 
    private function getToken(){
    	$appid = C('WEIXIN_APPID');
    	$secret = C('WEIXIN_APPSECRET');
    	$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$secret;
    	$response = api_get($url);
    	$response = json_to_array($response);
    	return $response['access_token'];
    }
    
    /**
     * @desc 获取公众平台服务器IP
     */
    private function getIP(){
    	$token = $this->getToken();
    	$url = 'https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token='.$token;
    	$response = api_get($url);
    	$response = json_to_array($response);
    	$ip_list = $response['ip_list'];
		return $ip_list;
    }
    
    /**
     * 自定义菜单接口
     */
    public function createMenu(){
    	$data = ' {
		     "button":[
    		 {
		          "type":"pic_weixin",
		          "name":"上传图片",
		          "key":"upload"
		     },
		     {	
		          "type":"view",
		          "name":"活动",
		          "url":"http://mp.weixin.qq.com/s?__biz=MzIxNTA5NTM5MA==&mid=2652327578&idx=1&sn=a73b47f03d83be61e980d6c48775cabc&scene=0#wechat_redirect"
		      },
		       {
		           "name":"联系客服",
		           "sub_button":[
		           {	
		               "type":"view",
		               "name":"紧急通知",
		               "url":"http://mp.weixin.qq.com/s?__biz=MzIxNTA5NTM5MA==&mid=2652327617&idx=2&sn=df481943261d353319ea35cc1d509be0&scene=4#wechat_redirect"
		            },
		            {
		               "type":"click",
		               "name":"客服",
		               "key":"kefu"
            	}]
    		}]
		 }';
    	$token = $this->getToken();
    	$url = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$token;
    	$_t = api_post($url,$data);
    	var_dump($_t);
    	exit;
    }

    /**
     * @desc 激光推送
     * @param  $deviceid
     */
    private function Jpush( $deviceid,$title ){
    	$mac = M('relation')->where(" deviceid = '{$deviceid}' ")->getField('mac');
    	//激光推送有图片上传通知
    	$Jpush = new \Common\Library\ORG\Util\Jpush();
    	$backData = $Jpush->push($receiver='all', $title,$mac,$m_type='',$m_txt='',$m_time=600);
    	return $backData;
    } 
    
    
    /**
     * @desc 对标记用户即时发送
     * @param $object 发送对象
     * @param $content 发送内容
     */
    private function tagsPush($object,$content = '',$title = '',$mac_bf,$val_arr = array()){
    	$result = $this->client->push()
    	//->setPlatform(array('android','ios'))
    	->setPlatform(array('android'))
    	->addAlias($object)
    	->addTag(array())
    	//->setNotificationAlert('')
    	//$val_arr = array("key1"=>"value1", "key2"=>"value2");
    	//->addAndroidNotification($content,$title, 1,$val_arr)//设置弹窗消息
    	//->addIosNotification("Hi, iOS notification", 'iOS sound', JPush::DISABLE_BADGE, true, 'iOS category', array("key1"=>"value1", "key2"=>"value2"))
    	->setMessage($content,$title, 'type', $val_arr)//设置不弹窗消息
    	->setOptions(100000, 3600, null, false)
    	->send();
    	$result->data->mac = $mac_bf;
    	return json_encode($result);
    }
    
    public function testJush(){
    	$mac_bf = 'B8-3D-4E-85-6F-64';
    	$mac_af = str_replace('-', '', $mac_bf);
    	$message = "{\"mac\":\"$mac_bf\"}";
    	$response = $this->tagsPush(array($mac_af),$message,'测试推送',$mac_bf);
    	dump(json_to_array($response));exit;
    }
    
    
    
    
    

    
    
    
    
}