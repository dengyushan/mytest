<?php
/**
 * @Copyright (C) 2015,
 * @Name  ApiController.class.php
 * @Author  Yangw
 * @Version  Beta 1.0
 * @Date:  2015-6-2
 * @Description Api管理控制器
 * @Class ApiController
 */
namespace Api\Controller;
use Think\Controller;
class ApiController extends Controller {
    
    private $iv = '0123456789123456'; //Same as in JAVA  
    private $key = '0123456789abcdef'; //Same as in JAVA  
    public function __construct(){
        parent::__construct();
    }
    /**
     * @desc 入口函数
     * @param 
     * @return
     */
    public function index(){
        $sercet_key = "fedcba9876543210";
        $sercet = $this->encrypt($sercet_key);
    }
    protected function hex2bin($hexdata) {  
        $bindata = '';  
        for ($i = 0; $i < strlen($hexdata); $i += 2) {  
              $bindata .= chr(hexdec(substr($hexdata, $i, 2)));  
        }  
        return $bindata;  
    }
    function encrypt($str) {  
        //$key = $this->hex2bin($key);      
        $iv = $this->iv;  
        $td = mcrypt_module_open('rijndael-128', '', 'cbc', $iv);  
        mcrypt_generic_init($td, $this->key, $iv);  
        $encrypted = mcrypt_generic($td, $str);  
        mcrypt_generic_deinit($td);  
        mcrypt_module_close($td);  
        return bin2hex($encrypted);  
    }  
    function decrypt($code) {  
        //$key = $this->hex2bin($key);  
        $code = $this->hex2bin($code);  
        $iv = $this->iv;  
        $td = mcrypt_module_open('rijndael-128', '', 'cbc', $iv);  
        mcrypt_generic_init($td, $this->key, $iv);  
        $decrypted = mdecrypt_generic($td, $code);  
        mcrypt_generic_deinit($td);  
        mcrypt_module_close($td);  
        return utf8_encode(trim($decrypted));  
    } 
}