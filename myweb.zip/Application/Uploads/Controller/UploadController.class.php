<?php
/**
 * @Copyright (C) 2015,
 * @Name  UploadController.class.php
 * @Author  Lzh
 * @Version  Beta 1.0
 * @Date:  2015-6-2
 * @Description 文件上传类
 * @Class UploadController
 */
namespace Uploads\Controller;
use Think\Controller;
class UploadController extends Controller {
	
	/**
	 * @desc  图片上传返回URL
	 * @param
	 * @return
	 */
	public function uploadImageUrl(){
		if (!empty($_FILES)) {
			$config = array(               //图片上传设置
					'maxSize'    =>    5*1024*1024,
					'rootPath'   =>    './',
					'savePath'   =>    'Public/Upload/Images/'.date("Y-m-d", time())."/",
					'saveName'   =>    array('uniqid',''),
					'exts'       =>    array('jpg','gif','png','jpeg'),
					'autoSub'    =>    false,
					'subName'    =>    array('date','Ymd'),
			);
			$upload = new \Think\Upload($config);// 实例化上传类
			$info   =   $upload->upload($_FILES);// 上传文件
			if($info) {// 上传成功
				foreach($info as $key=>$val){
					$path="/".$info[$key]['savepath'].$info[$key]['savename'];
					$path_arr[$key] = $path;
				}
			}else{// 上传失败 获取上传文件信息
				$err = $upload->getError();
				return $err;
			}
			return $path_arr;
		}
	}
	
	
    /**
     * @desc  图片上传
     * @param
     * @return
     */
    public function uploadImage(){
        if (!empty($_FILES)) {
            $key=  key($_FILES);
            $config = array(               //图片上传设置
                'maxSize'    =>    5*1024*1024,
                'rootPath'   =>    './',
                'savePath'   =>    'Public/Upload/Images/'.date("Y-m-d", time())."/",
                'saveName'   =>    array('uniqid',''),
                'exts'       =>    array('jpg','gif','png','jpeg'),
                'autoSub'    =>    false,
                'subName'    =>    array('date','Ymd'),
            );
            $upload = new \Think\Upload($config);// 实例化上传类
            $info   =   $upload->upload($_FILES);// 上传文件
            if($info) {// 上传成功
                echo $this->rootpath;
                $path="/".$info[$key]['savepath'].$info[$key]['savename'];
                $path = C('WEBSET_URL').$path;//保存全路径
                $result  = array('status'=>1,'msg'=>"上传成功",'url'=>$path);
                echo json_encode($result);exit;
                //return $result;
            }else{// 上传成功 获取上传文件信息
                $err = $upload->getError();
                $result  = array('status'=>-1,'msg'=>$err,);
                echo json_encode($result);exit;
                //return $result;
            }
        }
    }
	
    /**
     * @desc  应用图片上传
     * @param 
     * @return 
     */
    public function uploadAppImage(){
        if (!empty($_FILES)) {
            $key=  key($_FILES);
            $config = array(               //图片上传设置
                'maxSize'    =>    5*1024*1024, 
                'rootPath'   =>    './',
                'savePath'   =>    'Public/Upload/Images/'.date("Y-m-d", time())."/",
                'saveName'   =>    array('uniqid',''), 
                'exts'       =>    array('jpg','gif','png','jpeg'),  
                'autoSub'    =>    false,   
                'subName'    =>    array('date','Ymd'),
            );
            $upload = new \Think\Upload($config);// 实例化上传类
            $info   =   $upload->upload($_FILES);// 上传文件   
            if($info) {// 上传成功
                $path="/".$info[$key]['savepath'].$info[$key]['savename'];
                $result  = array('status'=>1,'msg'=>"上传成功",'url'=>$path);
                echo json_encode($result);exit;
            }else{// 上传成功 获取上传文件信息  
                $err = $upload->getError();
                $result  = array('status'=>-1,'msg'=>$err,); 
                echo json_encode($result);exit;
            }
        }
    }
    
    /**
     * @desc  影视图片上传
     * @param 
     * @return 
     */
    public function uploadVideoImage(){

        if (!empty($_FILES)) {
            $key=  key($_FILES);
            $config = array(               //图片上传设置
                'maxSize'    =>    5*1024*1024, 
                'rootPath'   =>    './',
                'savePath'   =>    'Public/Upload/Images/Video/'.date("Y-m-d", time())."/",
                'saveName'   =>    array('uniqid',''), 
                'exts'       =>    array('jpg','gif','png','jpeg'),  
                'autoSub'    =>    false,   
                'subName'    =>    array('date','Ymd'),
            );
            $upload = new \Think\Upload($config);// 实例化上传类
            $info   =   $upload->upload($_FILES);// 上传文件   
            if($info) {// 上传成功
                $path="/".$info[$key]['savepath'].$info[$key]['savename'];
                $imagesize=  getimagesize(".".$path);
                $imagesize[0]>$imagesize[1]?$type=$imagesize[0]."+".$imagesize[1]."+1":$type=$imagesize[0]."+".$imagesize[1]."+-1";
                $result  = array('status'=>1,'msg'=>"上传成功",'url'=>$path,'type'=>$type);
                echo json_encode($result);exit;
            }else{// 上传成功 获取上传文件信息  
                $err = $upload->getError();
                $result  = array('status'=>-1,'msg'=>$err,); 
                echo json_encode($result);exit;
            }
        }
    }
    /**
     * @desc  专题图片上传
     * @param 
     * @return 
     */
    public function uploadSpecialImage(){
        if (!empty($_FILES)) {
            $key=  key($_FILES);
            $config = array(               //图片上传设置
                'maxSize'    =>    5*1024*1024, 
                'rootPath'   =>    './',
                'savePath'   =>    'Public/Upload/Images/Special/'.date("Y-m-d", time())."/",
                'saveName'   =>    array('uniqid',''), 
                'exts'       =>    array('jpg','gif','png','jpeg'),  
                'autoSub'    =>    false,   
                'subName'    =>    array('date','Ymd'),
            );
            $upload = new \Think\Upload($config);// 实例化上传类
            $info   =   $upload->upload($_FILES);// 上传文件   
            if($info) {// 上传成功
                $path="/".$info[$key]['savepath'].$info[$key]['savename'];
                $result  = array('status'=>1,'msg'=>"上传成功",'url'=>$path);
                echo json_encode($result);exit;
            }else{// 上传成功 获取上传文件信息  
                $err = $upload->getError();
                $result  = array('status'=>-1,'msg'=>$err,); 
                echo json_encode($result);exit;
            }
        }
    }
    /**
     * @desc  apk上传
     * @param 
     * @return 
     */
    public function uploadApk(){
        if (!empty($_FILES)) {
            $key=  key($_FILES);
            $config = array(               //apk上传设置
                'maxSize'    =>    200*1024*1024, 
                'rootPath'   =>    './',
                'savePath'   =>    'Public/Upload/Apk/',
                'saveName'   =>    array('uniqid',''), 
                'exts'       =>    array('apk'),  
                'autoSub'    =>    false,   
                'subName'    =>    array('date','Ymd'),
            );
            $upload = new \Think\Upload($config);// 实例化上传类
            $info   =   $upload->upload($_FILES);// 上传文件   
            if($info) {// 上传成功
                $path="/".$info[$key]['savepath'].$info[$key]['savename'];
                $filesize1=sprintf("%.2f",$info[$key]['size']/1024/1024);
                $filemd5=  md5_file(".".$path);
                $result  = array('status'=>1,'msg'=>"上传成功",'url'=>$path,'filesize'=>$info[$key]['size'],'filesize1'=>$filesize1,'filename'=>$info[$key]['name'],'filemd5'=>$filemd5);
                $res=  getapkinfo('.'.$path);
                $res=array_merge($result,$res);
                echo json_encode($res);exit;
            }else{// 上传失败 
                $err = $upload->getError();
                $res  = array('status'=>-1,'msg'=>$err,); 
                echo json_encode($res);exit;
            }
        }
    }
    /**
     * @desc  系统升级apk上传
     * @param 
     * @return 
     */
    public function upSystemApk(){
        if (!empty($_FILES)) {
            $key=  key($_FILES);
            $config = array(               //apk上传设置
                'maxSize'    =>    200*1024*1024, 
                'rootPath'   =>    './',
                'savePath'   =>    'Public/Upload/System/Apk/',
                'saveName'   =>    array('uniqid',''), 
                'exts'       =>    array('apk'),  
                'autoSub'    =>    false,   
                'subName'    =>    array('date','Ymd'),
            );
            $upload = new \Think\Upload($config);// 实例化上传类
            $info   =   $upload->upload($_FILES);// 上传文件   
            if($info) {// 上传成功
                $path="/".$info[$key]['savepath'].$info[$key]['savename'];
                $filesize1=sprintf("%.2f",$info[$key]['size']/1024/1024);
                $result  = array('status'=>1,'msg'=>"上传成功",'url'=>$path,'filesize'=>$info[$key]['size'],'filesize1'=>$filesize1,'filename'=>$info[$key]['name']);
                $res=  getapkinfo('.'.$path);
                $res=array_merge($result,$res);
                echo json_encode($res);
            }else{// 上传失败 
                $err = $upload->getError();
                $result  = array('status'=>-1,'msg'=>$err,); 
                echo json_encode($result);exit;
            }
        }
    }
    /**
     * @desc  系统升级rom上传
     * @param 
     * @return 
     */
    public function upSystemRom(){
        if (!empty($_FILES)) {
            $key=  key($_FILES);
            $config = array(               //apk上传设置
                'maxSize'    =>    500*1024*1024, 
                'rootPath'   =>    './',
                'savePath'   =>    'Public/Upload/System/Rom/',
                'saveName'   =>    array('uniqid',''), 
                'exts'       =>    array('zip'),  
                'autoSub'    =>    false,   
                'subName'    =>    array('date','Ymd'),
            );
            
            $upload = new \Think\Upload($config);// 实例化上传类
            $info   =   $upload->upload($_FILES);// 上传文件   
            if($info) {// 上传成功
                $path="/".$info[$key]['savepath'].$info[$key]['savename'];
                $filesize1=sprintf("%.2f",$info[$key]['size']/1024/1024);
                $filemd5=  md5_file(".".$path);
                $result  = array('status'=>1,'msg'=>"上传成功",'url'=>$path,'filesize'=>$info[$key]['size'],'filemd5'=>$filemd5,'filesize1'=>$filesize1,'filename'=>$info[$key]['name']);
                //$res=  getapkinfo('.'.$path);
                //$res=array_merge($result,$res);
                echo json_encode($result);
            }else{// 上传失败 
                $err = $upload->getError();
                $result  = array('status'=>-1,'msg'=>$err,); 
                echo json_encode($result);exit;
            }
        }
    }
    /**
     * @desc  强制升级apk上传
     * @param 
     * @return 
     */
    public function upMandApk(){
        if (!empty($_FILES)) {
            $key=  key($_FILES);
            $config = array(               //apk上传设置
                'maxSize'    =>    200*1024*1024, 
                'rootPath'   =>    './',
                'savePath'   =>    'Public/Upload/MandApk/',
                'saveName'   =>    array('uniqid',''), 
                'exts'       =>    array('apk'),  
                'autoSub'    =>    false,   
                'subName'    =>    array('date','Ymd'),
            );
            $upload = new \Think\Upload($config);// 实例化上传类
            $info   =   $upload->upload($_FILES);// 上传文件   
            if($info) {// 上传成功
                $path="/".$info[$key]['savepath'].$info[$key]['savename'];
                $filesize1=sprintf("%.2f",$info[$key]['size']/1024/1024);
                $filemd5=  md5_file(".".$path);
                $result  = array('status'=>1,'msg'=>"上传成功",'url'=>$path,'filesize'=>$info[$key]['size'],'filesize1'=>$filesize1,'filename'=>$info[$key]['name'],'filemd5'=>$filemd5);
                $res=  getapkinfo('.'.$path);
                $res=array_merge($result,$res);
                echo json_encode($res);
            }else{// 上传失败 
                $err = $upload->getError();
                $res  = array('status'=>-1,'msg'=>$err,); 
                echo json_encode($res);
            }
        }
    }
    
    /**
     * @desc  视频上传
     * @param 
     * @return 
     */
    public function uploadVideos(){
        if (!empty($_FILES)) {
            $key=  key($_FILES);
            $config = array(               //图片上传设置
                'maxSize'    =>    2000*1024*1024, 
                'rootPath'   =>    './',
                'savePath'   =>    'Public/Upload/Vods/'.date("Y-m-d", time())."/",
                'saveName'   =>    array('uniqid',''), 
                'exts'       =>    array('jpg','gif','png','jpeg','mp4'),  
                'autoSub'    =>    false,   
                'subName'    =>    array('date','Ymd'),
            );
            $upload = new \Think\Upload($config);// 实例化上传类
            $info   =   $upload->upload($_FILES);// 上传文件   
            if($info) {// 上传成功
                $path="/".$info[$key]['savepath'].$info[$key]['savename'];
                $imagesize=  getimagesize(".".$path);
                $imagesize[0]>$imagesize[1]?$type=$imagesize[0]."+".$imagesize[1]."+1":$type=$imagesize[0]."+".$imagesize[1]."+-1";
                $result  = array('status'=>1,'msg'=>"上传成功",'url'=>$path,'type'=>$type);
                //$result['video'] = $this->getTime($path);
                //$video =  $this->getTime($path); //ffmpeg-php 没有安装
               // print_r($video);
                echo json_encode($result);exit;
            }else{// 上传失败  
                $err = $upload->getError(); echo $err;exit;
                $result  = array('status'=>-1,'msg'=>$err,); 
                echo json_encode($result);exit;
            }
        }
    }
    
    
    /**
     * @desc  删除文件
     * @param 
     * @return 
     */
    public function delFile($path) {
        if(!empty($path)){
        $path=".".$path;     
        $bool=unlink($path);
        ($bool==true)?$this->ajaxReturn(1):$this->ajaxReturn(-1);
        }
    }
    

    /**
     * @desc  获得视频文件的缩略图和视频长度,需要ffmpeg支持
     * @param 
     * @return 
     */
    function getTime($file){ 
        $vtime = exec("ffmpeg -i ".$file." 2>&1 | grep 'Duration' | cut -d ' ' -f 4 | sed s/,//");//总长度 
        $ctime = date("Y-m-d H:i:s",filectime($file));//创建时间 
        //$duration = explode(":",$time); 
        // $duration_in_seconds = $duration[0]*3600 + $duration[1]*60+ round($duration[2]);//转化为秒 
        return array(
            'vtime'=>$vtime, 
            'ctime'=>$ctime 
        ); 
    } 
    
}