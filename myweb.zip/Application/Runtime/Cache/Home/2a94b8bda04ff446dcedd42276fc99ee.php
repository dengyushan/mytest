<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<!--     <link rel="icon" href="/Public/image/home/icon_2.png"> -->
    <title>个人博客</title>
    <link href="/Public/css/home/index/foot.css" rel="stylesheet" type="text/css">
    <link href="/Public/css/home/index/cbody.css" rel="stylesheet" type="text/css">
    <link href="/Public/css/home/index/banner.css" rel="stylesheet" type="text/css">
    <link href="/Public/css/home/index/nav.css" rel="stylesheet" type="text/css">
    <link href="/Public/css/home/css.css" rel="stylesheet" type="text/css">
</head>
<body>
    <div class="nav">
<!--         <a class="nav_logo"><img src="/Public/image/home/logo.png"></a> -->
        <div id="nav_ul">
            <ul>
                <li><a class="nav_a" href="###" target="_self">迎阳</a></li>
                <li class="nav_line">|</li>
                <li><a class="nav_a"  href="###" target="_self">个人中心</a></li>
                <li class="nav_line">|</li>
                <li><a class="nav_a"  href="###" target="_self">发博文</a></li>
                <li class="nav_line">|</li>
                <li><a class="nav_a"  href="###" target="_self">消息</a></li>
            </ul>
        </div>
    </div>
    <div class="banner">
        <img id="banner_img" src="/Public/image/home/banner.png">
        <div id="banner_text">
            <a id="banner_text_a" href="#" target="_self">迎阳的博客</a>
            <div id="banner_content" >
                <ul>
                    <li><a href="###" target="_self">首页</a></li>
                    <li class="banner_line">|</li>
                    <li><a href="###" target="_self">博文目录</a></li>
                    <li class="banner_line">|</li>
                    <li><a href="###" target="_self">图片</a></li>
                    <li class="banner_line">|</li>
                    <li><a href="###" target="_self">关于我</a></li>
                </ul>
            </div>
        </div>
    </div>


    <div class="cbody">
        <div class="cbody_left">
            <div id="gr">
                <div class="cbody_bar">
                    <span><b>个人资料</b></span>
                </div>
                <div id="gr_tou">
                    <img id="gr_touxiang" src="/Public/image/home/touxiang.png">
                </div>
                <span id="name">迎阳</span>
                <div id="weibo">
                    <span>
<!--                     	<img id="weibo_icon" src="/Public/image/home/icon_1.png"> -->
                    	微博
                    </span>
                </div>
                <hr>
                <div id="list_ul">
                    <ul>
                    	<li>博客访问：<span>843</span></li>
                        <li>博客等级：<span>7</span></li>
                        <li>博客积分：<span>83</span></li>
                        <li>关注人气：<span>3</span></li>
                        <li>获赠金币：<span>0</span></li>
                        <li>赠出金币：<span>0</span></li>
                        <li>荣誉勋章：<span>7</span></li>
                    </ul>
                </div>
            </div>

            <div class="panel" id="lx">
                <div class="cbody_bar">
                    <div>
                        <span><b>QQ二维码</b></span>
                        <div id="lx_img">
                            <img src="/Public/image/home/erweima.png">
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="panel" id="lx">
                <div class="cbody_bar">
                    <div>
                        <span><b>微信二维码</b></span>
                        <div id="lx_img">
                            <img src="/Public/image/home/erweima.png">
                        </div>
                    </div>
                </div>
            </div>
<!--             <div class="panel" id="fl"> -->
<!--                 <div class="cbody_bar"> -->
<!--                     <div> -->
<!--                         <span><b>分类</b><a class="cbody_bar_span_a" href="###" target="_self">[管理]</a></span> -->
<!--                         <ul> -->
<!--                             <li>全部博文<span>(30)</span></li> -->
<!--                             <li>二级考证<span>(19)</span></li> -->
<!--                             <li>英语四级<span>(22)</span></li> -->
<!--                             <li>班级资料<span>(17)</span></li> -->
<!--                             <li>学术交流<span>(8)</span></li> -->
<!--                             <li>影视天地<span>(39)</span></li> -->
<!--                             <li>侃侃杂谈<span>(1)</span></li> -->
<!--                             <li>转载转发<span>(349)</span></li> -->
<!--                         </ul> -->
<!--                     </div> -->
<!--                 </div> -->
<!--             </div> -->
            <div class="panel" id="fk">
                <div class="cbody_bar">
                    <div id="fk_list">
                        <span><b>访客Ip</b></span>
                        <ul>
                            <li><img class="fk_img" src="/Public/image/home/costomer.png">引流助手<span class="fk_time">6月20日</span></li>
                            <li><img class="fk_img" src="/Public/image/home/costomer.png">记得小窝<span class="fk_time">6月20日</span></li>
                            <li><img class="fk_img" src="/Public/image/home/costomer.png">辣妈小衣橱<span class="fk_time">6月20日</span></li>
                            <li><img class="fk_img" src="/Public/image/home/costomer.png">wanwang013<span class="fk_time">6月20日</span></li>
                            <li><img class="fk_img" src="/Public/image/home/costomer.png">渔村<span class="fk_time">6月20日</span></li>
                            <li><img class="fk_img" src="/Public/image/home/costomer.png">124的巧合<span class="fk_time">6月20日</span></li>
                            <li><img class="fk_img" src="/Public/image/home/costomer.png">uu66tt<span class="fk_time">6月20日</span></li>
                            <li><img class="fk_img" src="/Public/image/home/costomer.png">我盼雨量<span class="fk_time">6月20日</span></li>
                            <li><img class="fk_img" src="/Public/image/home/costomer.png">爱你的我…<span class="fk_time">6月20日</span></li>
                            <li><img class="fk_img" src="/Public/image/home/costomer.png">用户45234…<span class="fk_time">6月20日</span></li>
                        </ul>
                        <hr>
                        <a id="fk_a" href="###" target="_self">更多>></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="cbody_right">
            <div id="bw">
                <div>
                    <div id="cbody_bar_r">
                        <span><b>博文</b></span>
                    </div>
                </div>


                <div class="bw_text">
                    <span class="title_span"><a class="bw_text_title" href="text.html">软件开发</a>(2016年6月29日)</span>
                    <br />
                    <span class="note_span">标签：<a class="note_span_a" href="###" target="_self">教程</a><a class="note_span_a" href="###" target="_self">视频</a><a class="note_span_a" href="###" target="_self">access</a> 
<!--                     		  分类：<a class="note_span_a" href="###" target="_self">二级考证</a> -->
                   	</span>
                    <div class="text_text">&nbsp;&nbsp;软件开发人员和数据架构师可以使用Microsoft Access开发应用软件,“高级用户”可以使用它来构建软件应用程序。和其他办公应用程序一样，ACCESS支持Visual Basic宏语言,它是一个面向对象的编程语言,可以引用各种对象，包括DAO(数据访问对象),ActiveX数据对象,以及许多其他的ActiveX组件。可视对象用于显示表和报表，他们的方法和属性是在VBA编程环境下，VBA代码模块可以声明和调用Windows操作系统函数。</div>
                    <br />
                    <span class="bw_bottom"><a class="bw_bottom_bt" href="###" target="_self">阅读</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">评论</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">转载</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">收藏</a>(10)<a class="bw_bottom_bt_more" href="text.html" target="_self">查看全文>></a></span>
                </div>
                <hr class="bw_hr">

                <div class="bw_text">
                    <span class="title_span"><a class="bw_text_title" href="text.html">特朗普提名埃克森美孚CEO出任美国国务卿</a>(2016年6月29日)</span>
                    <br />
                    <span class="note_span">标签：<a class="note_span_a" href="###" target="_self">教程</a><a class="note_span_a" href="###" target="_self">视频</a><a class="note_span_a" href="###" target="_self">access</a>    分类：<a class="note_span_a" href="###" target="_self">二级考证</a></span>
                    <div class="text_text">&nbsp;&nbsp; 据《今日美国》13日报道，在外界长达一个多月的猜测后，特朗普已提名埃克森美孚(Exxon Mobil Corp.)首席执行官雷克斯·蒂勒森( Rex Tillerson)为其新政府的国务卿。

  据一位不愿透露姓名的知情人士称，特朗普将于下周二正式对外宣布。13日，特朗普发表推特称将在明天早晨公布其国务卿人选。</div>
                    <br />
                    <span class="bw_bottom"><a class="bw_bottom_bt" href="###" target="_self">阅读</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">评论</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">转载</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">收藏</a>(10)<a class="bw_bottom_bt_more" href="###" target="_self">查看全文>></a></span>
                </div>
                <hr class="bw_hr">

                <div class="bw_text">
                    <span class="title_span"><a class="bw_text_title" href="text.html">男子发现珍贵达·芬奇手稿 估价1500万欧元</a>(2016年6月29日)<a class="bw_text_title_bt" href="###" target="_self">[编辑]</a><a class="bw_text_title_bt" href="###" target="_self">[删除]</a></span>
                    <br />
                    <span class="note_span">标签：<a class="note_span_a" href="###" target="_self">教程</a><a class="note_span_a" href="###" target="_self">视频</a><a class="note_span_a" href="###" target="_self">access</a>    分类：<a class="note_span_a" href="###" target="_self">二级考证</a></span>
                    <div class="text_text">&nbsp;&nbsp;　　中新网12月13日电 据外媒报道，日前，文艺复兴时期大师达·芬奇的一幅墨笔画手稿在法国亮相。拍卖行为这幅画估价1500万欧元。

　　据报道，这幅画的主人是法国一名退休医生。此前，这名男子将他的父亲收藏的10余幅画带到拍卖行。经鉴定，其中一幅尺寸7.5英寸乘5英寸的人像画应是出自达·芬奇的手稿集册《大西洋古抄本》，画作名为“圣塞巴斯蒂安的殉道”。</div>
                    <br />
                    <span class="bw_bottom"><a class="bw_bottom_bt" href="###" target="_self">阅读</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">评论</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">转载</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">收藏</a>(10)<a class="bw_bottom_bt_more" href="###" target="_self">查看全文>></a></span>
                </div>
                <hr class="bw_hr">

                <div class="bw_text">
                    <span class="title_span"><a class="bw_text_title" href="text.html">家长们有矛盾，为何不要三个孩子？</a>(2016年6月29日)<a class="bw_text_title_bt" href="###" target="_self">[编辑]</a><a class="bw_text_title_bt" href="###" target="_self">[删除]</a></span>
                    <br />
                    <span class="note_span">标签：<a class="note_span_a" href="###" target="_self">教程</a><a class="note_span_a" href="###" target="_self">视频</a><a class="note_span_a" href="###" target="_self">access</a>    分类：<a class="note_span_a" href="###" target="_self">二级考证</a></span>
                    <div class="text_text">&nbsp;&nbsp;11日下午，安徽六安市公安局金安分局三里桥派出所民警接到报警，称某小区有三个孩子被丢到路边，民警赶到现场了解到，三个孩子中，最大的女孩今年九岁，两个小的是龙凤胎，霍邱县人，孩子母亲将孩子从霍邱带到六安吃喜蛋，然后把孩子丟在吃喜蛋的某饭店。同在吃喜蛋的孩子姑姑又把孩子送到该小区，据说孩子的舅舅住在该小区。警方拨打三个孩子父母的电话，父母全部关机，联系其舅舅，大伯，姥爷，无一人愿意出面收养，互相推诿。</div>
                    <br />
                    <span class="bw_bottom"><a class="bw_bottom_bt" href="###" target="_self">阅读</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">评论</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">转载</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">收藏</a>(10)<a class="bw_bottom_bt_more" href="###" target="_self">查看全文>></a></span>
                </div>
                <hr class="bw_hr">

                <div class="bw_text">
                    <span class="title_span"><a class="bw_text_title" href="text.html">砖工月工资2万元，这钱你挣得到么？</a>(2016年6月29日)<a class="bw_text_title_bt" href="###" target="_self">[编辑]</a><a class="bw_text_title_bt" href="###" target="_self">[删除]</a></span>
                    <br />
                    <span class="note_span">标签：<a class="note_span_a" href="###" target="_self">教程</a><a class="note_span_a" href="###" target="_self">视频</a><a class="note_span_a" href="###" target="_self">access</a>    分类：<a class="note_span_a" href="###" target="_self">二级考证</a></span>
                    <div class="text_text">&nbsp;&nbsp;近日，一张砖工工资表在网上热传，表中显示，其中砖工平均月工资高达2万元，最少的也1万多元。

网友纷纷表示：“包工头的电话是多少？”“走，我们搬砖去吧！”看看砖工的工资，再看看自己的工资，你是否也会想到“辞职搬砖”呢？砖工的活好干么？</div>
                    <br />
                    <span class="bw_bottom"><a class="bw_bottom_bt" href="###" target="_self">阅读</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">评论</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">转载</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">收藏</a>(10)<a class="bw_bottom_bt_more" href="###" target="_self">查看全文>></a></span>
                </div>
                <hr class="bw_hr">

                <div class="bw_text">
                    <span class="title_span"><a class="bw_text_title" href="text.html">解放军第一代防弹背心</a>(2016年6月29日)<a class="bw_text_title_bt" href="###" target="_self">[编辑]</a><a class="bw_text_title_bt" href="###" target="_self">[删除]</a></span>
                    <br />
                    <span class="note_span">标签：<a class="note_span_a" href="###" target="_self">教程</a><a class="note_span_a" href="###" target="_self">视频</a><a class="note_span_a" href="###" target="_self">access</a>    分类：<a class="note_span_a" href="###" target="_self">二级考证</a></span>
                    <div class="text_text">&nbsp;&nbsp;中国60年代援助越南的防避弹衣。配发胡志明小道上的汽车兵（包括部分援越汽车兵）及少量装备高炮部队。因美军轰炸北越，胡志明小道的汽车兵（包括援越汽车兵）及高炮部队人员损失不小，中国应北越的请求研制出了第一代避弹衣，并及时援助越南。使中国军人及越南军人少受伤亡。中国高炮部队及援越汽车兵少量装备，主要是配发北越军人的。

全新带防弹内层。大约12斤。</div>
                    <br />
                    <span class="bw_bottom"><a class="bw_bottom_bt" href="###" target="_self">阅读</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">评论</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">转载</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">收藏</a>(10)<a class="bw_bottom_bt_more" href="###" target="_self">查看全文>></a></span>
                </div>
                <hr class="bw_hr">

                <div class="bw_text">
                    <span class="title_span"><a class="bw_text_title" href="text.html">厉害了：叙利亚军队T-55改型能打炮射导弹啊</a>(2016年6月29日)<a class="bw_text_title_bt" href="###" target="_self">[编辑]</a><a class="bw_text_title_bt" href="###" target="_self">[删除]</a></span>
                    <br />
                    <span class="note_span">标签：<a class="note_span_a" href="###" target="_self">教程</a><a class="note_span_a" href="###" target="_self">视频</a><a class="note_span_a" href="###" target="_self">access</a>    分类：<a class="note_span_a" href="###" target="_self">二级考证</a></span>
                    <div class="text_text">&nbsp;&nbsp;据俄罗斯《独立军事观察报》报道，叙利亚军队目前装备的坦克数量最多的还是T-55坦克。根据各种来源消息，在冲突开始之前，叙利亚军械库中共有1200-2000辆T-55坦克。其中最为现代化的是T-55MV坦克，这种改进型和坦克装备有“接触-1”爆炸反应装甲。1997年，叙利亚与乌克兰坦克工厂签署合同，对200辆T-55坦克进行了改造升级，包括装备一台新式的柴油机，爆炸反应装甲等设备。
该坦克装备弹道计算火控系统以及9K116武器系统，因此可以发射俄罗斯生产的9M117M“棱堡”100毫米炮射导弹。车体前部使用推土机刮土铲或特殊的栅栏进行了加固，由于使用了新型履带以及装备功率更为强大的V-46-5M发动机，坦克的机动性能得到了显著改善。</div>
                    <br />
                    <span class="bw_bottom"><a class="bw_bottom_bt" href="###" target="_self">阅读</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">评论</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">转载</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">收藏</a>(10)<a class="bw_bottom_bt_more" href="###" target="_self">查看全文>></a></span>
                </div>
                <hr class="bw_hr">

                <div class="bw_text">
                    <span class="title_span"><a class="bw_text_title" href="text.html">厉害了：叙利亚军队T-55改型能打炮射导弹啊</a>(2016年6月29日)<a class="bw_text_title_bt" href="###" target="_self">[编辑]</a><a class="bw_text_title_bt" href="###" target="_self">[删除]</a></span>
                    <br />
                    <span class="note_span">标签：<a class="note_span_a" href="###" target="_self">教程</a><a class="note_span_a" href="###" target="_self">视频</a><a class="note_span_a" href="###" target="_self">access</a>    分类：<a class="note_span_a" href="###" target="_self">二级考证</a></span>
                    <div class="text_text">&nbsp;&nbsp;据俄罗斯《独立军事观察报》报道，叙利亚军队目前装备的坦克数量最多的还是T-55坦克。根据各种来源消息，在冲突开始之前，叙利亚军械库中共有1200-2000辆T-55坦克。其中最为现代化的是T-55MV坦克，这种改进型和坦克装备有“接触-1”爆炸反应装甲。1997年，叙利亚与乌克兰坦克工厂签署合同，对200辆T-55坦克进行了改造升级，包括装备一台新式的柴油机，爆炸反应装甲等设备。
该坦克装备弹道计算火控系统以及9K116武器系统，因此可以发射俄罗斯生产的9M117M“棱堡”100毫米炮射导弹。车体前部使用推土机刮土铲或特殊的栅栏进行了加固，由于使用了新型履带以及装备功率更为强大的V-46-5M发动机，坦克的机动性能得到了显著改善。</div>
                    <br />
                    <span class="bw_bottom"><a class="bw_bottom_bt" href="###" target="_self">阅读</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">评论</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">转载</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">收藏</a>(10)<a class="bw_bottom_bt_more" href="###" target="_self">查看全文>></a></span>
                </div>
                <hr class="bw_hr">

                <div class="bw_text">
                    <span class="title_span"><a class="bw_text_title" href="text.html">解放军公布大批军机官方高清照 歼20赫然在列</a>(2016年6月29日)<a class="bw_text_title_bt" href="###" target="_self">[编辑]</a><a class="bw_text_title_bt" href="###" target="_self">[删除]</a></span>
                    <br />
                    <span class="note_span">标签：<a class="note_span_a" href="###" target="_self">教程</a><a class="note_span_a" href="###" target="_self">视频</a><a class="note_span_a" href="###" target="_self">access</a>    分类：<a class="note_span_a" href="###" target="_self">二级考证</a></span>
                    <div class="text_text">&nbsp;&nbsp;光阴抟转，岁月留痕。亲爱的战友，2016年即将过去，回望过去这一年，中国军队给我们留下了太多闪光的瞬间。此时此刻您也许正在参加硝烟滚滚的实战演习，此时此刻您也许在海上和风浪搏斗，此时此刻您也许驾驶战机升空战斗，此时此刻您也许脱下军装挥别军营，此时此刻您也许参加授衔仪式成为绿色方阵的一员，此时此刻您也许还在海外执行维和任务。无数个此时此刻无数个你组成了中国军队波澜壮阔的全景图。在这张全景图上，我们看到您始终用冲锋的姿态行走在人民军队变革的路上，年终之际，中国军事图片中心用这一年中有温度、有角度、有深度的光影片段向寒来暑往中奔波一年的战友们致敬！</div>
                    <br />
                    <span class="bw_bottom"><a class="bw_bottom_bt" href="###" target="_self">阅读</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">评论</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">转载</a>(10) | <a class="bw_bottom_bt" href="###" target="_self">收藏</a>(10)<a class="bw_bottom_bt_more" href="###" target="_self">查看全文>></a></span>
                </div>
                <hr class="bw_hr">
                <br />
                <br />
                <br />
            </div>
        </div>
    </div>


    <div class="foot">
        <p><a href="###" target="_self">新浪BLOG意见反馈留言板</a><a href="###" target="_self">不良信息反馈</a>电话：4006900000 提示音后按1键（按当地市话标准计费）　欢迎批评指正</p>
        <ul>
            <li>新浪简介</li><li>|</li>
            <li>About Sina</li><li>|</li>
            <li>广告服务</li><li>|</li>
            <li>联系我们</li><li>|</li>
            <li>招聘信息</li><li>|</li>
            <li>网站律师</li><li>|</li>
            <li>SINA English</li><li>|</li>
            <li>会员注册</li><li>|</li>
            <li>产品答疑</li>
        </ul>
<!--         <p>Copyright © 1996 - 2016 SINA Corporation, All Rights Reserved</p> -->
<!--         <p>新浪公司 版权所有</p> -->
    </div>
</body>
</html>