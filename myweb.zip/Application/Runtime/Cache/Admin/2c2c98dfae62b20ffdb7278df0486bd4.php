<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html class=" js csstransforms3d"><head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>系统设置</title>
	<link rel="stylesheet" href="/Public/css/admin/base.css">
	<link rel="stylesheet" href="/Public/css/admin/page.css">
	<!--[if lte IE 8]>
	<link href="css/ie8.css" rel="stylesheet" type="text/css"/>
	<![endif]-->
	<script type="text/javascript" src="/Public/js/admin/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/js/admin/main.js"></script>
	<script type="text/javascript" src="/Public/js/admin/modernizr.js"></script>
	<!--[if IE]>
	<script src="http://libs.useso.com/js/html5shiv/3.7/html5shiv.min.js"></script>
	<![endif]-->
</head>

<body style="background: #f6f5fa;">

	<!--content S-->
	<div class="super-content">
		<div class="superCtab">
			<div class="ctab-title zxtop-title clearfix"><h3>系统设置</h3></div>
		</div>
		
		<div class="publishArt">
			<div class="pubMain">
				<!--上传 S-->
				<div class="mb-upload-img clearfix">
					<div class="mb-uplod">
						<b>LOGO(PC端)</b>
						<div class="upload-Box">
							<div class="imgbox">
								<div class="bg"><a href="#" class="mb-delete-a">删除</a></div>
							</div>
							<span class="uplBtn"><i class="ico-load"></i>点击上传<input id="fileImage1" class="fileImageSlect" type="file" size="30" name="fileselect[]"></span>
						</div>
					</div>
					<div class="mb-uplod">
						<b>LOGO(移动端) </b>
						<div class="upload-Box">
							<div class="imgbox">
								<div class="bg"><a href="#" class="mb-delete-a">删除</a></div>
							</div>
							<span class="uplBtn"><i class="ico-load"></i>点击上传<input id="fileImage2" class="fileImageSlect" type="file" size="30" name="fileselect[]"></span>
						</div>
					</div>
					<div class="mb-uplod">
						<b>个人头像</b>
						<div class="upload-Box uploading">
							<div class="imgbox">
								<img src="/Public/image/admin/img_jrn.jpg">
								<div class="bg"><a href="#" class="mb-delete-a">删除</a></div>
							</div>
							<span class="uplBtn"><i class="ico-load"></i>点击上传<input id="fileImage3" class="fileImageSlect" type="file" size="30" name="fileselect[]"></span>
						</div>
					</div>
					<div class="mb-uplod">
						<b>微信二维码</b>
						<div class="upload-Box">
							<div class="imgbox">
								<div class="bg"><a href="#" class="mb-delete-a">删除</a></div>
							</div>
							<span class="uplBtn"><i class="ico-load"></i>点击上传<input id="fileImage4" class="fileImageSlect" type="file" size="30" name="fileselect[]"></span>
						</div>
					</div>
					<div class="mb-uplod">
						<b>形象展示</b>
						<div class="upload-Box">
							<div class="imgbox">
								<div class="bg"><a href="#" class="mb-delete-a">删除</a></div>
							</div>
							<span class="uplBtn"><i class="ico-load"></i>点击上传<input id="fileImage5" class="fileImageSlect" type="file" size="30" name="fileselect[]"></span>
						</div>
					</div>
				</div>
				<!--上传 E-->
				<h5 class="pubtitle">站点名称</h5>
				<div class="pub-txt-bar">
					<input type="text" class="shuruTxt">
				</div>
				<h5 class="pubtitle">SEO关键字</h5>
				<div class="pub-area-bar">
					<textarea name="" rows="" cols="3"></textarea>
				</div>
				<h5 class="pubtitle">站点描述</h5>
				<div class="pub-area-bar">
					<textarea name="" rows="" cols="3"></textarea>
				</div>
				<h5 class="pubtitle">站点访问统计代码</h5>
				<div class="pub-txt-bar">
					<input type="text" class="shuruTxt" placeholder="http://">
				</div>
				<h5 class="pubtitle">办公地点标注</h5>
				<div class="mb-baidu-bar">
					<span class="tip">调用百度地图API</span>
				</div>
				<div class="lxfs-tzyx clearfix">
					<ul class="clearfix">
						<li><h5 class="pubtitle">联系方式</h5>
							<input type="text" class="shuruTxt">
						</li>
						<li><h5 class="pubtitle">通知邮箱</h5>
							<input type="text" class="shuruTxt">
						</li>
					</ul>
				</div>
				<h5 class="pubtitle">模板颜色</h5>
				<div class="mb-color">
					<ul class="clearfix">
						<li class="active"><span class="red"></span><em>红色</em></li>
						<li><span class="blue"></span><em>蓝色</em></li>
					</ul>
				</div>
				<div class="pub-btn">
					<input type="button" id="" value="保存" class="saveBtn">
				</div>
			</div>
		</div>
	
		<!--main-->
	</div>
	<!--content E-->
	



</body></html>