<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html class=" js csstransforms3d"><head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>相册管理</title>
	<link rel="stylesheet" href="/Public/css/admin/base.css">
	<link rel="stylesheet" href="/Public/css/admin/page.css">
	<!--[if lte IE 8]>
	<link href="css/ie8.css" rel="stylesheet" type="text/css"/>
	<![endif]-->
	<script type="text/javascript" src="/Public/js/admin/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/js/admin/main.js"></script>
	<script type="text/javascript" src="/Public/js/admin/modernizr.js"></script>
	<!--[if IE]>
	<script src="http://libs.useso.com/js/html5shiv/3.7/html5shiv.min.js"></script>
	<![endif]-->
</head>

<body style="background: #f6f5fa;">

	<!--content S-->
	<div class="super-content RightMain" id="RightMain">
		
		<!--header-->
		<div class="superCtab">
			
			<div class="ctab-title clearfix">
				<h3>相册管理</h3>
				<div class="tbkaig"><span>同步开关</span><input type="checkbox" id="checkbox_d0" class="chk_4"><label for="checkbox_d0"></label></div>
			</div>
			
			<div class="ctab-Main">				
				<div class="ctab-Mian-cont">
					<div class="xc-btn-bar">
						<a href="javascript:;" class="greenbtn sp-add xc-add"><i class="ico-add"></i>添加相册</a>
					</div>
					
					<div class="xc-all-box clearfix">
						<div class="xc-list">
							<div class="img"><a href="xiangce_Content.html"><img src="/Public/image/admin/img_xc.jpg"></a><em>10</em></div>
							<div class="info clearfix">
								<h3><a href="xiangce_Content.html">公司公司2015年底聚餐2015年底聚餐……</a></h3>
								<em class="top">置顶</em>
								<span><input type="checkbox" id="checkbox_d1" class="chk_4"><label for="checkbox_d1"></label></span>
							</div>
							<div class="btn"><a href="#" class="xc-xiugai-a">修改</a><a href="#" class="xc-delete-a">删除</a></div>
						</div>
						<div class="xc-list">
							<div class="img"><a href="xiangce_Content.html"><img src="/Public/image/admin/img_xc.jpg"></a><em>10</em></div>
							<div class="info clearfix">
								<h3><a href="xiangce_Content.html">公司2015年底聚餐……</a></h3>
								<em class="top">置顶</em>
								<span><input type="checkbox" id="checkbox_d2" class="chk_4"><label for="checkbox_d2"></label></span>
							</div>
							<div class="btn"><a href="#" class="xc-xiugai-a">修改</a><a href="#" class="xc-delete-a">删除</a></div>
						</div>
						<div class="xc-list">
							<div class="img"><a href="xiangce_Content.html"><img src="/Public/image/admin/img_xc.jpg"></a><em>10</em></div>
							<div class="info clearfix">
								<h3><a href="xiangce_Content.html">公司2015年底聚餐……</a></h3>
								<em class="top">置顶</em>
								<span><input type="checkbox" id="checkbox_d3" class="chk_4"><label for="checkbox_d3"></label></span>
							</div>
							<div class="btn"><a href="#" class="xc-xiugai-a">修改</a><a href="#" class="xc-delete-a">删除</a></div>
						</div>
						<div class="xc-list">
							<div class="img"><a href="xiangce_Content.html"></a><em>10</em></div>
							<div class="info clearfix">
								<h3><a href="xiangce_Content.html">公司2015年底聚餐……</a></h3>
								<em class="top">置顶</em>
								<span><input type="checkbox" id="checkbox_d4" class="chk_4"><label for="checkbox_d4"></label></span>
							</div>
							<div class="btn"><a href="#" class="xc-xiugai-a">修改</a><a href="#" class="xc-delete-a">删除</a></div>
						</div>
					</div>
					<!--pages S-->
					<div class="pageSelect">
						<div class="pageWrap">
							<a class="pagePre"><i class="ico-pre">&nbsp;</i></a>
							<a href="#" class="pagenumb cur">1</a>
							<a href="#" class="pagenumb">2</a>
							<a href="#" class="pagenumb">3</a>
							<a href="#" class="pagenext"><i class="ico-next">&nbsp;</i></a>
						</div>
					</div>
					<!--pages E-->
				</div>
			</div>
		</div>
		<!--main-->
	</div>
	<!--content E-->
	
	<div class="layuiBg"></div><!--公共遮罩-->
	<!--添加相册弹出层-->
	<div class="addFeileibox addXcBox layuiBox">
		<div class="layer-title clearfix"><h2>添加相册</h2><span class="layerClose"></span></div>
		<div class="layer-content">
			<div class="aFllink clearfix"><span>相册名称</span></div>
			<div class="aFllink clearfix"><input type="text" value="新建相册"></div>
			<div class="aFlBtn"><input type="button" value="保存" class="saveBtn"></div>
		</div>
	</div>
	
	<!-- 修改弹出层-->
	<div class="addXcBox xcXgBox layuiBox">
		<div class="layer-title clearfix"><h2>修改相册</h2><span class="layerClose"></span></div>
		<div class="layer-content">
			<div class="aFllink clearfix"><span>相册名称</span></div>
			<div class="aFllink clearfix"><input type="text" value="公司2015年底聚餐活动相册"></div>
			<div class="aFlBtn"><input type="button" value="保存" class="saveBtn"></div>
		</div>
	</div>
	


</body></html>