<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html class=" js csstransforms3d"><head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>文章发布-发布</title>
	<link rel="stylesheet" href="/Public/css/admin/base.css">
	<link rel="stylesheet" href="/Public/css/admin/page.css">
	<!--[if lte IE 8]>
	<link href="css/ie8.css" rel="stylesheet" type="text/css"/>
	<![endif]-->
	<script type="text/javascript" src="/Public/js/admin/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/js/admin/main.js"></script>
	<script type="text/javascript" src="/Public/js/admin/modernizr.js"></script>
	<script type="text/javascript" src="/Public/js/admin/query.selectui.js"></script>
	
	<script type="text/javascript" charset="utf-8" src="/Public/js/admin/utf8-jsp/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/Public/js/admin/utf8-jsp/ueditor.all.min.js"> </script>
    <!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
    <!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
    <script type="text/javascript" charset="utf-8" src="/Public/js/admin/utf8-jsp/lang/zh-cn/zh-cn.js"></script>
	
	<link rel="stylesheet" type="text/css" href="/Public/js/admin/webuploader/webuploader.css">    
    <link rel="stylesheet" type="text/css" href="/Public/js/admin/webuploader/demo.css">
	
	<script>
	$(function($) {
		$("select").selectui({
			// 是否自动计算宽度
			autoWidth: true,
			// 是否启用定时器刷新文本和宽度
			interval: true
		});
	});
	</script>
	<!--[if IE]>
	<script src="http://libs.useso.com/js/html5shiv/3.7/html5shiv.min.js"></script>
	<![endif]-->
<link href="/Public/js/admin/utf8-jsp/themes/default/css/ueditor.css" type="text/css" rel="stylesheet">
<script src="/Public/js/admin/utf8-jsp/third-party/codemirror/codemirror.js" type="text/javascript" defer></script>
<link rel="stylesheet" type="text/css" href="/Public/js/admin/utf8-jsp/third-party/codemirror/codemirror.css">
<script src="/Public/js/admin/utf8-jsp/third-party/zeroclipboard/ZeroClipboard.js" type="text/javascript" defer></script></head>

<body style="background: rgb(246, 245, 250);">
	<!--content S-->
	<div class="super-content">
		
		<div class="superCtab">
			<div class="publishArt">
				<h4>发布文章</h4>
				<div class="pubMain">
					<a href="javascript:history.go(-1)" class="backlistBtn"><i class="ico-back"></i>返回列表</a>
					<form action="" method="post">
						<h5 class="pubtitle">选择分类</h5>
						<div class="pubselect">
							<span class="select_ui"><span class="select_text_ui" style="min-width: 6em;">请选择分类</span><b class="select_arrow"></b><select name="">
								<option value="">请选择分类</option>
								<option value="">请选择分类1</option>
							</select></span>
						</div>
						<h5 class="pubtitle">文章标题</h5>
						<div class="pub-txt-bar">
							<input type="text" class="shuruTxt">
						</div>
						<div class="pub-addflbtn"><a href="javascript:;" class="greenbtn add sp-add">添加标签</a></div>
						<h5 class="pubtitle">文章关键字</h5>
						<div class="pub-txt-bar">
							<input type="text" class="shuruTxt">
						</div>
						<h5 class="pubtitle">缩略图</h5>
						
						
						<div id="uploader" class="wu-example Thumbnails">
						    <div class="queueList">
						        <div id="dndArea" class="placeholder Thumblist">
						            <div id="filePicker" class="webuploader-container"><div class="webuploader-pick">点击选择图片</div><div id="rt_rt_1b286i1nj16u491ba32ee4188d1" style="position: absolute; top: 0px; left: 183.407px; width: 168px; height: 44px; overflow: hidden; bottom: auto; right: auto;"><input type="file" name="file" class="webuploader-element-invisible" multiple accept="image/*"><label style="opacity: 0; width: 100%; height: 100%; display: block; cursor: pointer; background: rgb(255, 255, 255);"></label></div></div>
						            <p>或将照片拖到这里，单次最多可选300张</p>
						            <div class="Thumblistbg upload-img">
										<input id="fileImage" type="file" size="30" name="fileselect[]" multiple>
										<a href="javascript:;" class="Thumbbtn"><i class="ico-download"></i>上传图片</a>
									</div>
						        </div>
						    <ul class="filelist"></ul></div>
						    <div class="statusBar" style="display:none;">
						        <div class="progress" style="display: none;">
						            <span class="text">0%</span>
						            <span class="percentage" style="width: 0%;"></span>
						        </div><div class="info">共0张（0B），已上传0张</div>
						        <div class="btns">
						            <div id="filePicker2" class="webuploader-container"><div class="webuploader-pick">继续添加</div><div id="rt_rt_1b286i1nr1urb1j6r9nfgv21dt36" style="position: absolute; top: 0px; left: 0px; width: 38px; height: 2px; overflow: hidden; bottom: auto; right: auto;"><input type="file" name="file" class="webuploader-element-invisible" multiple accept="image/*"><label style="opacity: 0; width: 100%; height: 100%; display: block; cursor: pointer; background: rgb(255, 255, 255);"></label></div></div><div class="uploadBtn state-pedding">开始上传</div>
						        </div>
						    </div>
						</div>
	
						
						<div class="Thumbnails clearfix">
							<div class="Thumblist" id="preview">
								<div class="Thumb_li">
									<div class="bg">
									<a href="javascript:" class="Thumb_delete" title="删除" data-index="0">删除</a>
									</div>
									<img src="/Public/image/admin/img-snt.jpg" class="upload_image">								
								</div>
								<div class="Thumb_li">
									<div class="bg" style="display: none;">
									<a href="javascript:" class="Thumb_delete" title="删除" data-index="0">删除</a>
									</div>
									<img src="/Public/image/admin/img-snt.jpg" class="upload_image">								
								</div>
							</div>
							<div class="Thumblistbg upload-img">
								<input id="fileImage" type="file" size="30" name="fileselect[]" multiple>
								<a href="javascript:;" class="Thumbbtn"><i class="ico-download"></i>上传图片</a>
							</div>
						</div>
						<h5 class="pubtitle">视频地址</h5>
						<div class="pub-txt-bar">
							<input type="text" class="shuruTxt" placeholder="http://">
						</div>
						<h5 class="pubtitle">文章简介</h5>
						<div class="pub-area-bar">
							<textarea name="" rows="" cols="3"></textarea>
						</div>
						<h5 class="pubtitle">文章内容</h5>
						
						<div class="pub-btn">
							<input type="button" id="" value="发布" class="saveBtn">
						</div>
					</form>
				</div>
			</div>
		
		</div>
		<!--main-->
		
	</div>
	<!--content E-->
	<!--点击修改弹出层-->
	<div class="layuiBg"></div><!--公共遮罩-->
	<!--点击添加标签弹出-->
	<div class="addFeileibox addSortBox layuiBox">
		<div class="layer-title clearfix"><h2>添加标签</h2><span class="layerClose"></span></div>
		<div class="layer-content">
			<div class="addSortMain clearfix">
				<span>保险</span><span data-id="lb1">保险</span><span data-id="lb2">保</span><span data-id="lb2">保险</span><span>保险</span><span>保险</span><span>保险</span><span>保险</span><span>保险</span><span>保险</span><span>保险</span><span>保险</span><span>保险</span><span>保险</span><span>保险</span>
			</div>
			<div class="addSortBtn"><input type="button" value="保存" class="saveBtn FuncsaveBtn"></div>
		</div>
	</div>
	

<script type="text/javascript">
// 添加全局站点信息
var BASE_URL = '/webuploader';
</script>
<!--引入JS-->
<script type="text/javascript" src="/Public/js/admin/webuploader/webuploader.js"></script>
<script type="text/javascript" src="/Public/js/admin/webuploader/demo.js"></script>
<script type="text/javascript">

    //实例化编辑器
    //建议使用工厂方法getEditor创建和引用编辑器实例，如果在某个闭包下引用该编辑器，直接调用UE.getEditor('editor')就能拿到相关的实例
    var ue = UE.getEditor('editor');


    function isFocus(e){
        alert(UE.getEditor('editor').isFocus());
        UE.dom.domUtils.preventDefault(e)
    }
    function setblur(e){
        UE.getEditor('editor').blur();
        UE.dom.domUtils.preventDefault(e)
    }
    function insertHtml() {
        var value = prompt('插入html代码', '');
        UE.getEditor('editor').execCommand('insertHtml', value)
    }
    function createEditor() {
        enableBtn();
        UE.getEditor('editor');
    }
    function getAllHtml() {
        alert(UE.getEditor('editor').getAllHtml())
    }
    function getContent() {
        var arr = [];
        arr.push("使用editor.getContent()方法可以获得编辑器的内容");
        arr.push("内容为：");
        arr.push(UE.getEditor('editor').getContent());
        alert(arr.join("\n"));
    }
    function getPlainTxt() {
        var arr = [];
        arr.push("使用editor.getPlainTxt()方法可以获得编辑器的带格式的纯文本内容");
        arr.push("内容为：");
        arr.push(UE.getEditor('editor').getPlainTxt());
        alert(arr.join('\n'))
    }
    function setContent(isAppendTo) {
        var arr = [];
        arr.push("使用editor.setContent('欢迎使用ueditor')方法可以设置编辑器的内容");
        UE.getEditor('editor').setContent('欢迎使用ueditor', isAppendTo);
        alert(arr.join("\n"));
    }
    function setDisabled() {
        UE.getEditor('editor').setDisabled('fullscreen');
        disableBtn("enable");
    }

    function setEnabled() {
        UE.getEditor('editor').setEnabled();
        enableBtn();
    }

    function getText() {
        //当你点击按钮时编辑区域已经失去了焦点，如果直接用getText将不会得到内容，所以要在选回来，然后取得内容
        var range = UE.getEditor('editor').selection.getRange();
        range.select();
        var txt = UE.getEditor('editor').selection.getText();
        alert(txt)
    }

    function getContentTxt() {
        var arr = [];
        arr.push("使用editor.getContentTxt()方法可以获得编辑器的纯文本内容");
        arr.push("编辑器的纯文本内容为：");
        arr.push(UE.getEditor('editor').getContentTxt());
        alert(arr.join("\n"));
    }
    function hasContent() {
        var arr = [];
        arr.push("使用editor.hasContents()方法判断编辑器里是否有内容");
        arr.push("判断结果为：");
        arr.push(UE.getEditor('editor').hasContents());
        alert(arr.join("\n"));
    }
    function setFocus() {
        UE.getEditor('editor').focus();
    }
    function deleteEditor() {
        disableBtn();
        UE.getEditor('editor').destroy();
    }
    function disableBtn(str) {
        var div = document.getElementById('btns');
        var btns = UE.dom.domUtils.getElementsByTagName(div, "button");
        for (var i = 0, btn; btn = btns[i++];) {
            if (btn.id == str) {
                UE.dom.domUtils.removeAttributes(btn, ["disabled"]);
            } else {
                btn.setAttribute("disabled", "true");
            }
        }
    }
    function enableBtn() {
        var div = document.getElementById('btns');
        var btns = UE.dom.domUtils.getElementsByTagName(div, "button");
        for (var i = 0, btn; btn = btns[i++];) {
            UE.dom.domUtils.removeAttributes(btn, ["disabled"]);
        }
    }

    function getLocalData () {
        alert(UE.getEditor('editor').execCommand( "getlocaldata" ));
    }

    function clearLocalData () {
        UE.getEditor('editor').execCommand( "clearlocaldata" );
        alert("已清空草稿箱")
    }
    
</script>


</body></html>