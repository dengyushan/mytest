<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html class=" js csstransforms3d"><head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>咨询管理－团队</title>
	<link rel="stylesheet" href="/Public/css/admin/base.css">
	<link rel="stylesheet" href="/Public/css/admin/page.css">
	<!--[if lte IE 8]>
	<link href="css/ie8.css" rel="stylesheet" type="text/css"/>
	<![endif]-->
	<script type="text/javascript" src="/Public/js/admin/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/js/admin/main.js"></script>
	<script type="text/javascript" src="/Public/js/admin/modernizr.js"></script>
	<!--[if IE]>
	<script src="http://libs.useso.com/js/html5shiv/3.7/html5shiv.min.js"></script>
	<![endif]-->
</head>

<body style="background: #f6f5fa;">

	<!--content S-->
	<div class="super-content">
		<div class="superCtab">
			<div class="ctab-title clearfix"><h3>咨询管理</h3><a href="javascript:;" class="sp-column"><i class="ico-export"></i>导出列表</a></div>
			
			<div class="ctab-Main">
				
				<div class="ctab-Mian-cont">
					<div class="Mian-cont-btn Mian-cont-btn2 clearfix">
						<div class="operateBtn">
							<div class="wd-msg">您有  <span>2</span> 条未读咨询信息！</div>
						</div>
						<div class="searchBar">
							<input type="text" id="" value="" class="form-control srhTxt" placeholder="输入子站关键字搜索">
							<input type="button" class="srhBtn" value="">
						</div>
					</div>
					
					<div class="Mian-cont-wrap">
						<div class="defaultTab-T">
							<table border="0" cellspacing="0" cellpadding="0" class="defaultTable">
								<tbody><tr><th class="t_1">子站ID</th><th class="t_2_1">子站名称</th><th>操作</th></tr>
							</tbody></table>
						</div>
						<table border="0" cellspacing="0" cellpadding="0" class="defaultTable defaultTable2">
							<tbody><tr class="wd">
								<td class="t_1">2015001</td>
								<td class="t_2_1"><a href="/index.php/Admin/Question/subweb" class="team-a">张三个人官网</a></td>
								<td class="alcenter"><a href="#" class="export-a">导出数据</a></td>
							</tr>
							<tr class="wd">
								<td class="t_1">2015001</td>
								<td class="t_2_1"><a href="/index.php/Admin/Question/subweb" class="team-a">张三个人官网</a></td>
								<td class="alcenter"><a href="#" class="export-a">导出数据</a></td>
							</tr>
							<tr>
								<td class="t_1">2015001</td>
								<td class="t_2_1"><a href="/index.php/Admin/Question/subweb" class="team-a">张三个人官网</a></td>
								<td class="alcenter"><a href="#" class="export-a">导出数据</a></td>
							</tr>
							<tr>
								<td class="t_1">2015001</td>
								<td class="t_2_1"><a href="/index.php/Admin/Question/subweb" class="team-a">张三个人官网</a></td>
								<td class="alcenter"><a href="#" class="export-a">导出数据</a></td>
							</tr>
							<tr>
								<td class="t_1">2015001</td>
								<td class="t_2_1"><a href="/index.php/Admin/Question/subweb" class="team-a">张三个人官网</a></td>
								<td class="alcenter"><a href="#" class="export-a">导出数据</a></td>
							</tr>
							<tr>
								<td class="t_1">2015001</td>
								<td class="t_2_1"><a href="/index.php/Admin/Question/subweb" class="team-a">张三个人官网</a></td>
								<td class="alcenter"><a href="#" class="export-a">导出数据</a></td>
							</tr>
							<tr>
								<td class="t_1">2015001</td>
								<td class="t_2_1"><a href="/index.php/Admin/Question/subweb" class="team-a">张三个人官网</a></td>
								<td class="alcenter"><a href="#" class="export-a">导出数据</a></td>
							</tr>
							<tr>
								<td class="t_1">2015001</td>
								<td class="t_2_1"><a href="/index.php/Admin/Question/subweb" class="team-a">张三个人官网</a></td>
								<td class="alcenter"><a href="#" class="export-a">导出数据</a></td>
							</tr>
							<tr>
								<td class="t_1">2015001</td>
								<td class="t_2_1"><a href="/index.php/Admin/Question/subweb" class="team-a">张三个人官网</a></td>
								<td class="alcenter"><a href="#" class="export-a">导出数据</a></td>
							</tr>
						</tbody></table>
						<!--pages S-->
						<div class="pageSelect">
							<span>共 <b>188</b> 条 每页 <b>10 </b>条   1/18</span>
							<div class="pageWrap">
								<a class="pagePre"><i class="ico-pre">&nbsp;</i></a>
								<a href="#" class="pagenumb cur">1</a>
								<a href="#" class="pagenumb">2</a>
								<a href="#" class="pagenumb">3</a>
								<a href="#" class="pagenext"><i class="ico-next">&nbsp;</i></a>
							</div>
						</div>
						<!--pages E-->
					</div>
				</div>
			</div>
		</div>
		<!--main-->
		
	</div>
	<!--content E-->




</body></html>