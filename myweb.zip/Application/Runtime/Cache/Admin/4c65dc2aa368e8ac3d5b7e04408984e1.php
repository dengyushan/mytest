<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html class=" js csstransforms3d"><head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>图片管理-PC端－首页通栏</title>
	<link rel="stylesheet" href="/Public/css/admin/base.css">
	<link rel="stylesheet" href="/Public/css/admin/page.css">
	<!--[if lte IE 8]>
	<link href="css/ie8.css" rel="stylesheet" type="text/css"/>
	<![endif]-->
	<script type="text/javascript" src="/Public/js/admin/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/js/admin/main.js"></script>
	<script type="text/javascript" src="/Public/js/admin/modernizr.js"></script>
	<!--[if IE]>
	<script src="http://libs.useso.com/js/html5shiv/3.7/html5shiv.min.js"></script>
	<![endif]-->
</head>

<body style="background: #f6f5fa;">

	<!--content S-->
	<div class="super-content RightMain" id="RightMain">
		
		<!--header-->
		<div class="superCtab">
			<div class="tp-title clearfix">
				<h3>图片管理</h3>
				<div class="tp-mng-box clearfix">
					<a href="javascript:;" class="tp-zdy-a sp-column"><i class="ico-zdy"></i>自定义栏目名称</a>
					<div class="tp-zhongduan">
						<span><a href="tupian_pc_index.html">PC端</a><i class="ico-tri"></i></span>
						<div class="hide-zd" style="display: none;"><a href="tupian_yd_index.html">移动端</a></div>
					</div>
				</div>
			</div>
			
			<div class="ctab-Main">
				<div class="ctab-Main-title">
					<ul class="clearfix">
						<li class="cur"><a href="tupian_pc_index.html">首页通栏</a></li>
						<li><a href="tupian_pc_jzg.html">价值观</a></li>
						<li><a href="tupian_pc_td.html">团队风采</a></li>
						<li><a href="tupian_pc_rm.html">热门产品</a></li>
						<li><a href="tupian_pc_zy.html">卓越联盟</a></li>
						<li><a href="tupian_pc_yq.html">友情链接</a></li>
						<li><a href="tupian_pc_ny.html">内页左侧</a></li>
					</ul>
				</div>
				
				<div class="ctab-Mian-cont">
					<div class="Mian-cont-btn tp-cnt-btn clearfix">
						<div class="tp-xl-box tp-tit-kg">
							<span>图片标题<i class="ico-tri"></i></span>
							<ul class="hide-menu">
								<li class="on"><a href="javascript:;">开</a></li>
								<li><a href="javascript:;">关</a></li>
							</ul>
						</div>
						<div class="operateBtn">
							<a href="javascript:;" class="greenbtn add sp-photo">添加图片<input id="fileImage" class="fileImgtp" type="file" size="30" name="fileselect[]" multiple=""></a>
						</div>
					</div>
					
					<div class="xc-all-box clearfix">
						<div class="xc-list tp-list">
							<div class="img"><a href="xiangce_Content.html"><img src="/Public/image/admin/img_xc.jpg"></a></div>
							<div class="info clearfix">
								<h3>标题图片</h3>
								<em class="top">置顶</em>
								<span><input type="checkbox" id="checkbox_d1" class="chk_4"><label for="checkbox_d1"></label></span>
							</div>
							<div class="input">
								<input type="text" class="txt txtbiaoti">
								<h4>图片链接</h4>
								<input type="text" class="txt">
							</div>
							<div class="btn clearfix"><a href="#" class="xc-bc-a">保存</a><a href="#" class="xc-delete-a">删除</a></div>
						</div>
						<div class="xc-list tp-list">
							<div class="img"><a href="xiangce_Content.html"><img src="/Public/image/admin/img_xc.jpg"></a></div>
							<div class="info clearfix">
								<h3>标题图片</h3>
								<em class="top">置顶</em>
								<span><input type="checkbox" id="checkbox_d2" class="chk_4" checked=""><label for="checkbox_d2"></label></span>
							</div>
							<div class="input">
								<input type="text" class="txt txtbiaoti">
								<h4>图片链接</h4>
								<input type="text" class="txt">
							</div>
							<div class="btn clearfix"><a href="#" class="xc-bc-a">保存</a><a href="#" class="xc-delete-a">删除</a></div>
						</div>
						<div class="xc-list tp-list">
							<div class="img"><a href="xiangce_Content.html"><img src="/Public/image/admin/img_xc.jpg"></a></div>
							<div class="info clearfix">
								<h3>标题图片</h3>
								<em class="top">置顶</em>
								<span><input type="checkbox" id="checkbox_d3" class="chk_4" checked=""><label for="checkbox_d3"></label></span>
							</div>
							<div class="input">
								<input type="text" class="txt txtbiaoti">
								<h4>图片链接</h4>
								<input type="text" class="txt">
							</div>
							<div class="btn clearfix"><a href="#" class="xc-bc-a">保存</a><a href="#" class="xc-delete-a">删除</a></div>
						</div>
						<div class="xc-list tp-list">
							<div class="img"><a href="xiangce_Content.html"><img src="/Public/image/admin/img_xc.jpg"></a></div>
							<div class="info clearfix">
								<h3>标题图片</h3>
								<em class="top">置顶</em>
								<span><input type="checkbox" id="checkbox_d4" class="chk_4" checked=""><label for="checkbox_d4"></label></span>
							</div>
							<div class="input">
								<input type="text" class="txt txtbiaoti">
								<h4>图片链接</h4>
								<input type="text" class="txt">
							</div>
							<div class="btn clearfix"><a href="#" class="xc-bc-a">保存</a><a href="#" class="xc-delete-a">删除</a></div>
						</div>
						<div id="preview"></div>
					</div>
					
					<!--pages S-->
					<div class="pageSelect">
						<div class="pageWrap">
							<a class="pagePre"><i class="ico-pre">&nbsp;</i></a>
							<a href="#" class="pagenumb cur">1</a>
							<a href="#" class="pagenumb">2</a>
							<a href="#" class="pagenumb">3</a>
							<a href="#" class="pagenext"><i class="ico-next">&nbsp;</i></a>
						</div>
					</div>
					<!--pages E-->
				</div>
			</div>
		</div>
		<!--main-->
		
	</div>
	<!--content E-->
	
	<div class="layuiBg"></div><!--公共遮罩-->
	<!--栏目管理-->
	<div class="Columnbox layuiBox">
		<div class="layer-title clearfix"><h2>自定义栏目名称</h2><span class="layerClose"></span></div>
		<div class="layer-content">
			<ul class="colu-title clearfix">
				<li class="li-1">栏目名称</li><li class="li-2">英文名称</li><li class="li-3">操作</li><li class="li-4">同步开关</li>
			</ul>
			<div class="colu-list">
				<ul class="colu-cont clearfix active">
					<li class="li-1">首页通栏</li><li class="li-2">life</li><li class="li-3"><a href="javascript:;" class="colu-xg">修改</a></li><li class="li-4"><input type="checkbox" id="checkbox_d_1" class="chk_4"><label for="checkbox_d_1"></label></li>
				</ul>
			</div><!--首页通栏-->
			<div class="colu-list">
				<ul class="colu-cont clearfix">
					<li class="li-1">价值观</li><li class="li-2">values</li><li class="li-3"><a href="javascript:;" class="colu-xg">修改</a></li><li class="li-4"><input type="checkbox" id="checkbox_d_2" class="chk_4"><label for="checkbox_d_2"></label></li>
				</ul>
			</div><!--价值观-->
			<div class="colu-list">
				<ul class="colu-cont clearfix">
					<li class="li-1">团队风采</li><li class="li-2">about</li><li class="li-3"><a href="javascript:;" class="colu-xg">修改</a></li><li class="li-4"><input type="checkbox" id="checkbox_d_3" class="chk_4"><label for="checkbox_d_3" checked=""></label></li>
				</ul>
			</div><!--团队风采-->
			<div class="colu-list">
				<ul class="colu-cont clearfix">
					<li class="li-1">热门产品</li><li class="li-2">products</li><li class="li-3"><a href="javascript:;" class="colu-xg">修改</a></li><li class="li-4"><input type="checkbox" id="checkbox_d_4" class="chk_4" checked=""><label for="checkbox_d_4"></label></li>
				</ul>
			</div><!--热门产品-->
			<div class="colu-list">
				<ul class="colu-cont clearfix">
					<li class="li-1">卓越联盟</li><li class="li-2">aliance</li><li class="li-3"><a href="javascript:;" class="colu-xg">修改</a></li><li class="li-4"><input type="checkbox" id="checkbox_d_5" class="chk_4" checked=""><label for="checkbox_d_5"></label></li>
				</ul>
			</div><!--卓越联盟-->
			<div class="colu-list">
				<ul class="colu-cont clearfix">
					<li class="li-1">友情链接</li><li class="li-2">diaplsy</li><li class="li-3"><a href="javascript:;" class="colu-xg">修改</a></li><li class="li-4"><input type="checkbox" id="checkbox_d_6" class="chk_4"><label for="checkbox_d_6"></label></li>
				</ul>
			</div><!--友情链接-->
			<div class="colu-list">
				<ul class="colu-cont clearfix">
					<li class="li-1">快捷分类</li><li class="li-2">link</li><li class="li-3"><a href="javascript:;" class="colu-xg">修改</a></li><li class="li-4"><input type="checkbox" id="checkbox_d_7" class="chk_4"><label for="checkbox_d_7"></label></li>
				</ul>
			</div><!--快捷分类-->
			
		</div>
	</div>
	<!--栏目管理－修改-->
	<div class="ColumnXgbox layuiBox">
		<div class="layer-title clearfix"><h2>修改栏目名称</h2><span class="layerClose"></span></div>
		<div class="layer-content">
			<div class="aFllink clearfix"><span>栏目名称：</span><input type="text" value=""></div>
			<div class="aFllink clearfix"><span>英文名称：</span><input type="text" value=""></div>
			<div class="aFllink clearfix"><span>同步开关：</span>
				<div class="kg">
					<ul>
						<li><input type="checkbox" id="checkbox_d_xg_1" class="chk_4"><label for="checkbox_d_xg_1"></label></li>
						<li><input type="checkbox" id="checkbox_d_xg_2" class="chk_4" checked=""><label for="checkbox_d_xg_2"></label></li>
					</ul>
				</div>				
			</div>
			<div class="aFlBtn"><input type="button" value="保存" class="saveBtn"></div>
		</div>
	</div>


<script type="text/javascript" src="/Public/js/admin/zxxFile.js"></script>
<script>
var params = {
	fileInput: $("#fileImage").get(0),
	upButton: $("#fileSubmit").get(0),
	url: $("#uploadForm").attr("action"),
	filter: function(files) {
		var arrFiles = [];
		for (var i = 0, file; file = files[i]; i++) {
			if (file.type.indexOf("image") == 0) {
				if (file.size >= 512000) {
					alert('您这张"'+ file.name +'"图片大小过大，应小于500k');	
				} else {
					arrFiles.push(file);	
				}			
			} else {
				alert('文件"' + file.name + '"不是图片。');	
			}
		}
		return arrFiles;
	},
	onSelect: function(files) {
		var html = '', i = 0;
		$("#preview").html('<div class="upload_loading"></div>');
		var funAppendImage = function() {
			file = files[i];
			if (file) {
				var reader = new FileReader()
				reader.onload = function(e) {
					html = html + '<div class="xc-list tp-list"><div class="img"><a href="#"><img id="uploadImage_' + i + '" src="' + e.target.result + '" class="upload_image"/></a></div>'+ 
						'<div class="info clearfix"><h3>标题图片</h3><em class="top">置顶</em><span><input type="checkbox" id="checkbox_a'+ i +'" class="chk_4"/><label for="checkbox_a'+ i +'"></label></span></div>'+
						'<div class="input"><input type="text" class="txt txtbiaoti" value="' + file.name + '" /><h4>图片链接</h4><input type="text" class="txt" /></div>'+
						'<div class="btn clearfix"><a href="#" class="xc-bc-a">保存</a><a href="#" class="xc-delete-a upload_delete" href="javascript:" title="删除" data-index="'+ i +'">删除</a></div>' +
					'</div>';
					i++;
					funAppendImage();
					
					$(".xc-delete-a").click(function() {
						$(this).parent().parent().remove();
					});
				}
				reader.readAsDataURL(file);
			} else {
				$("#preview").html(html);
				if (html) {
					//删除方法
					$(".xc-delete-a").click(function() {
						ZXXFILE.funDeleteFile(files[parseInt($(this).attr("data-index"))]);
						return false;	
					});
					//提交按钮显示
					$("#fileSubmit").show();	
				} else {
					//提交按钮隐藏
					$("#fileSubmit").hide();	
				}
			}
		};
		funAppendImage();		
	},
	onDelete: function(file) {
		$("#uploadList_" + file.index).fadeOut();
	},
	onDragOver: function() {
		$(this).addClass("upload_drag_hover");
	},
	onDragLeave: function() {
		$(this).removeClass("upload_drag_hover");
	},
	onProgress: function(file, loaded, total) {
		var eleProgress = $("#uploadProgress_" + file.index), percent = (loaded / total * 100).toFixed(2) + '%';
		eleProgress.show().html(percent);
	},
	onSuccess: function(file, response) {
		$("#uploadInf").append("<p>上传成功，图片地址是：" + response + "</p>");
	},
	onFailure: function(file) {
		$("#uploadInf").append("<p>图片" + file.name + "上传失败！</p>");	
		$("#uploadImage_" + file.index).css("opacity", 0.2);
	},
	onComplete: function() {
		//提交按钮隐藏
		$("#fileSubmit").hide();
		//file控件value置空
		$("#fileImage").val("");
		$("#uploadInf").append("<p>当前图片全部上传完毕，可继续添加上传。</p>");
	}
};
ZXXFILE = $.extend(ZXXFILE, params);
ZXXFILE.init();

</script>

</body></html>