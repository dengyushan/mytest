<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html class=" js csstransforms3d"><head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>模板管理</title>
	<link rel="stylesheet" href="/Public/css/admin/base.css">
	<link rel="stylesheet" href="/Public/css/admin/page.css">
	<!--[if lte IE 8]>
	<link href="css/ie8.css" rel="stylesheet" type="text/css"/>
	<![endif]-->
	<script type="text/javascript" src="/Public/js/admin/jquery.min.js"></script>
	<script type="text/javascript" src="/Public/js/admin/main.js"></script>
	<script type="text/javascript" src="/Public/js/admin/modernizr.js"></script>
	<!--[if IE]>
	<script src="http://libs.useso.com/js/html5shiv/3.7/html5shiv.min.js"></script>
	<![endif]-->
</head>

<body style="background: #f6f5fa;">

	<!--content S-->
	<div class="super-content">
		<div class="superCtab">
			<div class="ctab-title zxtop-title clearfix"><h3>模板管理</h3></div>
		</div>
		
		<div class="ctab-Main">
			<div class="ctab-Mian-cont">
				<div class="mb-Main-box clearfix">
					<div class="mblist">
						<div class="img"><img src="/Public/image/admin/img-mb.jpg"></div>
						<h4>经典红-免费</h4>
						<div class="btn clearfix">
							<a href="#" class="usingBtn">使用中</a>
						</div>
					</div>
					<div class="mblist">
						<div class="img"><img src="/Public/image/admin/img-mb.jpg"></div>
						<h4>天空蓝-￥50.00元/月</h4>
						<div class="btn clearfix">
							<a href="#" class="previewBtn">预览</a>
							<a href="#" class="buyBtn">购买</a>
						</div>
					</div>
					<div class="mblist">
						<div class="img"><img src="/Public/image/admin/img-mb.jpg"></div>
						<h4>天空蓝-￥50.00元/月</h4>
						<div class="btn">
							<a href="#" class="previewBtn">预览</a>
							<a href="#" class="buyBtn">购买</a>
						</div>
					</div>
					<div class="mblist">
						<div class="img"><img src="/Public/image/admin/img-mb.jpg"></div>
						<h4>天空蓝-￥50.00元/月</h4>
						<div class="btn">
							<a href="#" class="previewBtn">预览</a>
							<a href="#" class="buyBtn">购买</a>
						</div>
					</div>
				</div>
				
				<!--pages S-->
				<div class="pageSelect">
					<div class="pageWrap">
						<a class="pagePre"><i class="ico-pre">&nbsp;</i></a>
						<a href="#" class="pagenumb cur">1</a>
						<a href="#" class="pagenumb">2</a>
						<a href="#" class="pagenumb">3</a>
						<a href="#" class="pagenext"><i class="ico-next">&nbsp;</i></a>
					</div>
				</div>
				<!--pages E-->
			</div>
		
		</div>
		<!--main-->
	</div>
	<!--content E-->
	


</body></html>