<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Model;
class WeiboController extends Controller {
	public function __construct() {
		parent::__construct();
	}
	
	public function index(){
		$this->display();
	}

	public function publish(){
		$this->display();
	}



}