<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Model;
class QuestionController extends Controller {
	public function __construct() {
		parent::__construct();
	}
	
	public function index(){
		$this->display();
	}

	/**
	 * @desc 子站
	 */
	public function subweb(){
		$this->display();
		
	}

}