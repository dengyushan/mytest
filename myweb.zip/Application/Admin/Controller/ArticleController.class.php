<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Model;
class ArticleController extends Controller {
	public function __construct() {
		parent::__construct();
	}
	
	public function index(){
		$this->display();
	}




}