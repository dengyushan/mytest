<?php
/**
 * @Copyright (C) 2015
* @Name  UserModel.class.php
* @Author  dengyushan
* @Version  Beta 1.0
* @Date:  2015-12-02
* @Description 用户model
*/
namespace Common\Model;
class TestModel extends BaseModel{
	protected $tableName = 'insert_1';
	protected $tablePrefix = '';
	protected $pk = '';
	public function __construct() {
		parent::__construct();
	}
}