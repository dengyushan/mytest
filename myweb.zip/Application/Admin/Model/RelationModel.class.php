<?php
/**
 * @Copyright (C) 2015
* @Name  UserModel.class.php
* @Author  dengyushan
* @Version  Beta 1.0
* @Date:  2015-12-02
* @Description 用户model
*/
namespace Common\Model;
class RelationModel extends BaseModel{
	protected $tableName = 'relation';
	protected $tablePrefix = '';
	protected $pk = '';
	public function __construct() {
		parent::__construct();
	}
	
	/**
	 * @desc 判断此mac地址是否已经绑定设备
	 * @param  $mac
	 */
	public function isBind( $mac ){
		$row = $this->where("mac = '$mac'")->find();
		if( is_array($row) ){
			return true;
		}else{
			return false;	
		}
	}
	
	/**
	 * @desc 查寻二维码图片地址
	 * @param $mac
	 */
	public function getQrcodePath( $mac ){
		$qrcode = $this->where("mac = '$mac'")->getField('qrcode');
		return $qrcode;
	}
	
	/**
	 * @desc 给mac绑定device_id
	 * @param $mac
	 */
	public function linkDeviceid(){
		$list = $this->field('deviceid')->where(" mac = '' ")->order('id asc')->select();
		return $list[0]['deviceid'];
	}
	
	/**
	 * @desc 保存mac与deviceid关系
	 * @param $mac
	 * @param $deviceid
	 */
	public function saveData( $deviceid,$mac ){
		$this->where(" deviceid = '$deviceid' ")->setField(array('mac'=>$mac,'bindtime'=>time(),'status'=>1));
	}
	
	/**
	 * @desc 根据mac获取deviceid
	 * @param $mac
	 */
	public function getDeviceid( $mac ){
	    $deviceid = $this->where(" mac = '{$mac}' ")->getField('deviceid');
		return $deviceid;
	}
	
	/**
	 * @desc 根据deviceid获取mac
	 * @param $deviceid
	 */
	public function getMac( $deviceid ){
		$mac = $this->where(" deviceid = '{$deviceid}' ")->getField('mac');
		return $mac;
	}
	

	
	
	
}