<?php
/**
 * @Copyright (C) 2015
* @Name  PictureModel.class.php
* @Author  dengyushan
* @Version  Beta 1.0
* @Date:  2015-12-02
* @Description 用户model
*/
namespace Common\Model;
class PictureModel extends BaseModel{
	protected $tableName = 'picture';
	protected $tablePrefix = '';
	protected $pk = '';
	public function __construct() {
		parent::__construct();
	}
	
	/**
	 * @desc 获取图片
	 * @param $deviceid
	 * @return array
	 */
	public function getPicture( $deviceid ){
		$list = $this->where(" deviceid = '{$deviceid}' and isdel = 0 and care = 1 ")->order('addtime desc')->select();
		return $list;
	}

	
	/**
	 * @desc 删除图片
	 * @param $pid
	 */
	public function delPicModel( $pid ){
		//$modify = $this->where("pid = $pid")->setField(array('isdel'=>1));
		$modify = $this->where("pid = $pid")->delete();
		if( $modify ){
			return true;
		}else{
			return false;
		}
		
	}
}