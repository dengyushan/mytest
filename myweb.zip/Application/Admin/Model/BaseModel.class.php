<?php 
/**
 * @Copyright (C) 2015
 * @Name  BaseModel.class.php
 * @Author  dengyushan
 * @Version  Beta 1.0
 * @Date:  2015-12-02
 * @Description 基础model
 */
namespace Common\Model;
use Think\Model;
class BaseModel extends Model {

    public function __construct() {
       parent::__construct();  
    }
 	
 	public function Lists($where,$field='*',$page=10,$order){
        $count = $this->field($field)->where($where)->count();
        $p = getpage($count, $page);
        $list = $this->where($where)->field($field)->limit($p->firstRow,$p->listRows)
        ->order($order)->select();
        return array(
            'page'=>$p->show(),
            'list'=>$list
        );
    }
}