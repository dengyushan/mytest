<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model;
class IndexController extends Controller {
	//private $insert;
	public function __construct() {
		parent::__construct();
		//$this->insert = new \Common\Model\TestModel();
	}
	
	public function index(){
		//echo 'haha';exit;
		//$result = M('relation')->select();
		//var_dump($result);exit;
		$this->display();
	}
	
	
	
	
}