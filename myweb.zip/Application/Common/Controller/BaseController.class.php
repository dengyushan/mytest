<?php
/**
 * @Copyright (C) 2015,
 * @Name  BaseController.class.php
 * @Author  yangw
 * @Version  Beta 1.0
 * @Date:  2015-3-13
 * @Description 基础控制类
 * @Class BaseController
 */
namespace Common\Controller;
use Think\Controller;
class BaseController extends Controller {
   
    protected $download_url;
    
    function __construct(){
    	parent::__construct();
        $this->download_url =  "http://".$_SERVER['SERVER_NAME']."/"; //下载地址全局变量
    	$this->_init();
    }

    /**
     * @desc 初始化加载
     * @param 
     * @return 
     */
    private function _init(){
        if(!session('username')) { 
            $this->redirect('/');
        }
      //  $this->_get_status();
        $this->_get_current();
      //  $this->_get_chres();
      //  $this->_get_power();
      //  $this->_getfromdata();
    }
    
    /**
     * @desc 获取当前登录账号信息，包括渠道ID
     * @param 
     * @return array(),返回用户信息以及当前所在渠道信息
     */
    protected function userInfo() {
        $username = session("username");
        $where = array("UserName" => $username);
        $user = new \Common\Model\UserModel();
        $userinfo = $user->where($where)->select();
        $channel = new \Common\Model\ChannelModel();
        $channelInfo = $channel->where(array("ChannelId" => $userinfo[0]['channelid']))->select();
        $array = array("user" => $userinfo[0], "channel"  => $channelInfo[0]);
        return $array;
    }


    /**
     * @desc 获取当前页面URL，设置CSS样式用
     * @param 
     * @return 
     */
    private function _get_current(){
        $module=MODULE_NAME;
        $contro=CONTROLLER_NAME;
        $action=ACTION_NAME;  
        $this->assign("model", $module);
        $this->assign("contro", $contro);
        $this->assign("action", $action);
        $upload_url = $this->download_url."index.php/";
        $this->assign("upload_url", $upload_url);
    }
    


    /**
     * @desc  SimpleXMLElement 对象转换为 PHP 数组
     * @param $xml 对象
     * @return
     */
    protected function xmlToArr ($xml, $root = true) {
        if (!$xml->children()) { 
            return (string) $xml; 
        } 
        $array = array(); 
        foreach ($xml->children() as $element => $node) { 
            $totalElement = count($xml->{$element}); 
            if (!isset($array[$element])) { 
                $array[$element] = ""; 
            } 
            // Has attributes 
            if ($attributes = $node->attributes()) { 
                $data = array( 
                    'attributes' => array(), 
                    'value' => (count($node) > 0) ? $this->xmlToArr($node, false) : (string) $node 
                ); 
                foreach ($attributes as $attr => $value) { 
                    $data['attributes'][$attr] = (string) $value; 
                } 
                if ($totalElement > 1) { 
                    $array[$element][] = $data; 
                } else { 
                 $array[$element] = $data; 
                } 
            // Just a value 
            } else { 
                if ($totalElement > 1) { 
                    $array[$element][] = $this->xmlToArr($node, false); 
                } else { 
                    $array[$element] = $this->xmlToArr($node, false); 
                } 
            } 
        } 
        if ($root) { 
            return array($xml->getName() => $array); 
        } else { 
            return $array; 
        } 
    }

    
    /**
     * @desc 数据源
     * @param $xml 对象
     * @return
     */
    private function _getfromdata() {
        $module=MODULE_NAME;
        if($module=="Vod"||$module=="vod"||$module=="Channel"||$module=="channel"){
            $Chdata=new \Common\Model\ChdataModel();
            $where['A.channelid']= $this->topchannelid;
            $where['A.status']=  1;
            $res=$Chdata->getData($where,-1, "B.id,B.apiname");
            $this->fdata=$res[1];
            $this->assign("fdata",$res[1]);
        }
    }
} 