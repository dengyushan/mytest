<?php
return array(
    /* 数据库设置 */
	'DB_TYPE'               =>  'mysql',     // 数据库类型
	'DB_HOST'               =>  '59.110.26.36',//'127.0.0.1', // 服务器地址
	'DB_NAME'               =>  'bdm257698404_db',//'yunfang',          // 数据库名
	'DB_USER'               =>  'bdm257698404',//      // 用户名
	'DB_PWD'                =>  'bdm2576984046616',//, // 密码
	'DB_PORT'               =>  '3306',        // 端口	
    'DB_PREFIX'             =>  '',    // 数据库表前缀
    'SESSION_AUTO_START'    =>  true,    // 是否自动开启Session
	'MODULE_ALLOW_LIST' => array('Home','Api','Admin'), //允许访问模块
    'DEFAULT_MODULE'        =>  'Home',  // 默认模块
	'DEFAULT_CONTROLLER'    => 'Index', //默认控制器
    'ROOT_URL'              => "/index.php/",
	'VAR_MODULE'            =>  'module',     // 默认模块获取变量
	'VAR_CONTROLLER'        =>  'controller',    // 默认控制器获取变量
	'VAR_ACTION'            =>  'action',    // 默认操作获取变量
	'URL_MODEL'             =>  2,
	'TMPL_ACTION_ERROR'     =>  'Public/error', // 默认错误跳转对应的模板文件
	'TMPL_ACTION_SUCCESS'   =>  'Public/ok', // 默认成功跳转对应的模板文件
	'TMPL_PARSE_STRING'  =>array(
		'__IMAGE__'	=> '/Public/image',	//后台IMAGE公共目录
		'__CSS__'		=> '/Public/css',// 后台CSS公共目录
		'__JS__'		=> '/Public/js',// 后台JS公共目录
		'__UPLOAD__' => '/Public/upload',//后面上传文件公共目录
		'__MYWEB__' => 'http://www.myweb.local/',
	),
		
);