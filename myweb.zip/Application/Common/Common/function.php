<?php
/**
 * 生成二维码
 */
function createBarcode($content) {
	require_once("./Application/Common/Library/phpqrcode/phpqrcode.php");
	//定义纠错级别
	$errorLevel = "L";
	//定义生成图片宽度和高度;默认为3
	$size = 8;
	//定义生成内容
	//文件名
	$fileName = substr(microtime(),17,4).substr(microtime(),6,4).'.png';
	//保存路径
	$save_path = C('WEIXIN_QRCODE_PATH');
	//不存在遇创建路径
	if(!is_dir($save_path)){
		mkdir($save_path,0777,'recursive');//recursive 是递归生成目录
	}
	//调用QRcode类的静态方法png生成二维码图片//
	QRcode::png($content,$save_path.'/'.$fileName, $errorLevel, $size,$margin = 4, $saveandprint=false);
}

/**
 * @desc curl方式get请求
 * @param $url get请求地址
 */
function api_get($url)
{
	$ch = curl_init($url); //初始化
	curl_setopt($ch, CURLOPT_HEADER, 0); // 不返回header部分
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 返回字符串，而非直接输出
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //不验证证书
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //不验证证书
	curl_setopt($ch, CURLOPT_USERAGENT, "Dalvik/1.6.0 (Linux; U; Android 4.1.2; DROID RAZR HD Build/9.8.1Q-62_VQW_MR-2)");
	curl_setopt($ch, CURLOPT_REFERER, "-");
	$response = curl_exec($ch);
	return $response;
}

/**
 * @desc curl方式post请求
 * @param  $url post请求地址
 * @param $curlPost post 内容
 */
function api_post($url,$curlPost)
{
	$ch = curl_init($url); //初始化
	curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
	curl_setopt($ch, CURLOPT_HEADER, 0); // 不返回header部分
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 返回字符串，而非直接输出
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //不验证证书
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //不验证证书
	curl_setopt($ch, CURLOPT_USERAGENT, "Dalvik/1.6.0 (Linux; U; Android 4.1.2; DROID RAZR HD Build/9.8.1Q-62_VQW_MR-2)");
	curl_setopt($ch, CURLOPT_REFERER, "-");
	curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
	$response = curl_exec($ch);
	curl_close($ch);
	return $response;
}

/**
 * @desc json数据转化成数组格式
 * @param $data 要转化的数据
 */
function json_to_array($data){
	$data = json_decode($data,true);
	return $data;
}

/**
 * @desc 发送邮件 
 * @param  $email 邮箱
 * @param  $code  验证码
 */
function sentMail( $email,$code ){
		require_once("./Application/Common/Library/ORG/PHPMailer/class.phpmailer.php");
		require_once("./Application/Common/Library/ORG/PHPMailer/class.smtp.php");
		 $mail = new \PHPMailer();
		 $mail->IsSMTP ();
		 // SMTP 邮件服务器地址，这里需要替换为发送邮件的邮箱所在的邮件服务器地址
		 $mail->Host = C('EMAIL_HOST');      //$siteMail['mail']['host'];
		 //邮件服务器验证开
		 $mail->SMTPAuth = true;
		 // SMTP服务器上此邮箱的用户名，有的只需要@前面的部分，有的需要全名。请替换为正确的邮箱用户名
		 $mail->Username = C('EMAIL_USERNAME'); //$siteMail['mail']['email'];
		 // SMTP服务器上该邮箱的密码，请替换为正确的密码
		 $mail->Password = C('EMAIL_PASSWORD'); //$siteMail['mail']['password'];
		 // SMTP服务器上发送此邮件的邮箱，请替换为正确的邮箱  ,与$mail->Username 的值是对应的。
		 $mail->From = C('EMAIL_USERNAME');//$siteMail['mail']['username'];
		 // 真实发件人的姓名等信息，这里根据需要填写
		 $mail->FromName = C('EMAIL_FROMNAME'); //$siteMail['mail']['name'];
		 // 这里指定字符集！
		 $mail->CharSet = "utf-8";
		 //$mail->Encoding = 'base64';
		 // 收件人邮箱和姓名
		 $mail->AddAddress( $email );
		 // 发送 HTML邮件
		 $mail->IsHTML(true);
		 // 邮件主题
		 $mail->Subject ="Nutizen Verify Registration"; //$emailType['emailSubject'];
		 // 邮件内容
		 $body = '<p>Dear User,</p>';
		 $body.= '<p>Selamat Datang ke Nutizen!</p>';
		 $body.= '<p>Terima kasih telah mendaftar dengan kami. </p>';
		 $body.= '<p>Username kamu: < <font color="red"><b>'.$email.'</b></font> ></p>';
		 $body.= '<p>Activation Code:< <font color="red"><b>'.$code.'</b></font> ></p>';
		 $mail->Body = $body;
		 $mail->AltBody = "text/html";
		 //var_dump($mail->Send());
		 if (!$mail->Send()) {
		 	$status = false;
		 } else {
		 	$status = true;
		 }
}

/**
 * @desc 检测验证码
 * @param $code为输入的验证码字符串
 * @param  'seKey'为验证码加密密钥,和生成验证码时候密钥一致
 * @return bool
 */
function CheckVerify($code, $id = ''){
    $config =array('seKey'=>'cnmfucktmd');  // 验证码加密密钥
    $verify = new \Think\Verify($config);    
    return $verify->check($code, $id);
}

/**
 * @desc 删除图片
 * @param $path
 * @bool
 */
function unlinkPic( $path ){
	$_t = unlink($path);
	return $_t;
}

/**
* @desc 检测验证码
* @param $code为输入的验证码字符串
* @param  'seKey'为验证码加密密钥,和生成验证码时候密钥一致
* @return bool
*/
function getLevelData($res){
    for($i=0;$i<count($res);$i++){
        if($res[$i]['level']==1){
            $level1[]=$res[$i];
        }
        if($res[$i]['level']==2){
            $level2[]=$res[$i];
        }
        if($res[$i]['level']==3){
            $level3[]=$res[$i];
        }
    }
    foreach ($level2 as $key => $value) {
        foreach ($level3 as $k => $v) {
            if($value['id']==$v['father_id']){
                $level2[$key]['data'][]=$v;
            }
        }
    }
    foreach ($level1 as $key => $value) {
        foreach ($level2 as $k => $v) {
            if($value['id']==$v['father_id']){
                $level1[$key]['data'][]=$v;
            }
        }
    }
    return $level1;
}
// Xml 转 数组, 包括根键，忽略空元素和属性，尚有重大错误
function xml_to_array( $xml )
{
    $reg = "/<(\\w+)[^>]*?>([\\x00-\\xFF]*?)<\\/\\1>/";
    if(preg_match_all($reg, $xml, $matches))
    {
        $count = count($matches[0]);
        $arr = array();
        for($i = 0; $i < $count; $i++)
        {
            $key= $matches[1][$i];
            $val = xml_to_array( $matches[2][$i] );  // 递归
            if(array_key_exists($key, $arr))
            {
                if(is_array($arr[$key]))
                {
                    if(!array_key_exists(0,$arr[$key]))
                    {
                        $arr[$key] = array($arr[$key]);
                    }
                }else{
                    $arr[$key] = array($arr[$key]);
                }
                $arr[$key][] = $val;
            }else{
                $arr[$key] = $val;
            }
        }
        return $arr;
    }else{
        return $xml;
    }
}
// Xml 转 数组, 不包括根键
function xmltoarray( $xml )
{
    $arr = xml_to_array($xml);
    $key = array_keys($arr);
    return $arr[$key[0]];
}
/**
 * TODO 基础分页的相同代码封装，使前台的代码更少
 * @param $m 模型，引用传递
 * @param $where 查询条件
 * @param int $pagesize 每页查询条数
 * @return ThinkPage
 */
function getpage($count, $pagesize = 10) {
   $p = new \Common\Library\Page($count, $pagesize);
   $p->setConfig('header', '<div class="fr page-info">total <span class="color-green">%TOTAL_ROW%</span> entries,total <span class="color-green">%TOTAL_PAGE%</span> pages</div>');
   $p->setConfig('prev', '<i class="icon icon-page-prev"></i>');
   $p->setConfig('next', '<i class="icon icon-page-next"></i>');
   $p->setConfig('last', '<i class="icon icon-page-last"></i>');
   $p->setConfig('first', '<i class="icon icon-page-first"></i>');
   $p->setConfig('theme', '<ul>%FIRST%%UP_PAGE%%LINK_PAGE%%DOWN_PAGE%%END%</ul>%HEADER%');
   $p->lastSuffix = false;//最后一页不显示为总页数
   return $p;
}

function getmypage($count, $pagesize = 10) {
   $p = new Common\Library\ORG\Util\Page($count, $pagesize);
   $p->setConfig('header', '<span class="pagin_num pagin_pages">共<em>%TOTAL_PAGE%</em>页</span><span class="pagin_num pagin_pages"><em>%TOTAL_ROW%</em>条记录</span>');
   $p->setConfig('prev', '上一页');
   $p->setConfig('next', '下一页');
   $p->setConfig('last', '末页');
   $p->setConfig('first', '首页');
   $p->setConfig('theme', '%FIRST%%UP_PAGE%%LINK_PAGE%%DOWN_PAGE%%END%%HEADER%');
   $p->lastSuffix = false;//最后一页不显示为总页数
   return $p;
}
/**
 * TODO ajax分页
 * @param $where 查询条件
 * @param int $pagesize 每页查询条数
 * @return ThinkPage
 */
function ajax_page($count, $pagesize = 10) {
   $p = new \Common\Library\ORG\Util\Ajaxpage($count, $pagesize);
   $p->setConfig('prev', '<span aria-hidden="true" class="icons"></span>');
   $p->setConfig('next', '<span aria-hidden="true" class="icons"></span>');
   $p->setConfig('last', '末页');
   $p->setConfig('first', '首页');
   $p->setConfig('url', '/index.php/Channel/recommend/ajaxGetList/');
   return $p;
}

/**
 * TODO ajax针对数组分页
 * @param $array 要分页的数组
 * @param $where 查询条件
 * @param int $pagesize 每页查询条数
 * @return ThinkPage
 */
function array_ajax_page($count = 0, $pagesize = 10,$current = 0) {
    $p = new \Common\Library\ORG\Util\ArrayAjaxpage($count, $pagesize,$current);
   // $p->setConfig('header', '</ul><span class="pages-cur">第<em class="em-c">%NOW_PAGE%</em>页</span><span class="pages-all">共<em class="em-c">%TOTAL_PAGE%</em>页</span><span class="allNum">共<em class="em-c">%TOTAL_ROW%</em>条记录</span>');
    $p->setConfig('prev', '上一页');
    $p->setConfig('next', '下一页');
    $p->setConfig('last', '末页');
    $p->setConfig('first', '首页');

    //$p->setConfig('theme', '%FIRST%%UP_PAGE%%LINK_PAGE%%DOWN_PAGE%%END%%HEADER%');
    //$p->lastSuffix = true;//最后一页不显示为总页数
    return $p;
}

/*
 * 计算时间差转换成:小时-分钟-秒
 */
function counttime($begin_time,$end_time)
{
     if($begin_time < $end_time){
        $starttime = $begin_time;
        $endtime = $end_time;
     }
     else{
        $starttime = $end_time;
        $endtime = $begin_time;
     }
     $timediff = $endtime-$starttime;
     $days = intval($timediff/86400);
     $remain = $timediff%86400;
     $hours = intval($remain/3600);
     $remain = $remain%3600;
     $mins = intval($remain/60);
     $secs = $remain%60;
     $res = array("day" => $days,"hour" => $hours,"min" => $mins,"sec" => $secs);
     $hours=$res['day']*24+$res['hour'];
     return $hours.":".$res['min'].":".$res['sec'];
}

function alink($url = ""){
    $url=strtolower($url);
    $ur= explode("/", $url);
    if(count($ur)==1){
        $where['D.power_module']=$ur[0];
        $where['D.power_contro']="";
        $where['D.power_action']="";
    }else if(count($ur)==2){
        $where['D.power_module']=$ur[0];
        $where['D.power_contro']=$ur[1];
        $where['D.power_action']="";
    }else{
        $where['D.power_module']=$ur[0];
        $where['D.power_contro']=$ur[1];
        $where['D.power_action']=$ur[2];
    }
    $where['A.userid']=session('userid');
}

function getIP($queryIP){ 
    $url = 'http://ip.qq.com/cgi-bin/searchip?searchip1='.$queryIP; 
    $ch = curl_init($url); 
    curl_setopt($ch,CURLOPT_ENCODING ,'gb2312'); 
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true) ; // 获取数据返回 
    $result = curl_exec($ch); 
    $result = mb_convert_encoding($result, "utf-8", "gb2312"); // 编码转换，否则乱码 
    curl_close($ch); 
    preg_match("@<span>(.*)</span></p>@iU",$result,$ipArray); 
    $loc = $ipArray[1]; 
    return $loc; 
} 



function getapkinfo($apkpath){
    $appObj = new \Common\Library\ORG\Util\Apk();
    $appObj->open($apkpath); 
    $res = array(
        'package' => $appObj->getPackage(),
        'vername' => $appObj->getVersionName(),
        'vernumber' => $appObj->getVersionCode(),

    );
    return $res;
}
/**
 * TODO 去掉左右空格
 * @param $data 需要去掉空格的数据
 * @return ThinkPage
 */
function dotrim($data) {
   if (is_array($data) && !empty($data)) {
       foreach ($data as $k => $v) {
           if (is_array($v)) {
               $data[$k] = dotrim($v);
           } else {
               $data[$k] = trim($v);
           }
       }
   }
   return $data;
}

/**
 * TODO 到处Excel
 * @param $fileName string 导出的文件名字
 * @param $headArr array() 头部信息
 * @param $data array() 导出的内容数组
 * @return 
 */
function getExcel($fileName,$headArr,$data){
    //导入PHPExcel类库，因为PHPExcel没有用命名空间，只能import导入
    import("Org.Util.PHPExcel");
    import("Org.Util.PHPExcel.Writer.Excel5");
    import("Org.Util.PHPExcel.IOFactory.php");
    //对数据进行检验
    if(empty($data) || !is_array($data)){
        die("data must be a array");
    }
    //检查文件名
    if(empty($fileName)){
        exit;
    }
    $date = date("Y_m_d",time());
    $fileName .= "_{$date}.xls";
    //创建PHPExcel对象，注意，不能少了\
    $objPHPExcel = new \PHPExcel();
    $objProps = $objPHPExcel->getProperties();		
    //设置表头
    $key = ord("A");
    foreach($headArr as $v){
        $colum = chr($key);
        $objPHPExcel->setActiveSheetIndex(0) ->setCellValue($colum.'1', $v);
        $key += 1;
    }    
    $column = 2;
    $objActSheet = $objPHPExcel->getActiveSheet();
    foreach($data as $key => $rows){ //行写入
        $span = ord("A");
        foreach($rows as $keyName=>$value){// 列写入
            $j = chr($span);
            $objActSheet->setCellValue($j.$column, $value);
            $span++;
        }
        $column++;
    }

    $fileName = iconv("utf-8", "gb2312", $fileName);
    //重命名表
    // $objPHPExcel->getActiveSheet()->setTitle('test');
    //设置活动单指数到第一个表,所以Excel打开这是第一个表
    $objPHPExcel->setActiveSheetIndex(0);
    header('Content-Type: application/vnd.ms-excel');
    header("Content-Disposition: attachment;filename=\"$fileName\"");
    header('Cache-Control: max-age=0');
    $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save('php://output'); //文件通过浏览器下载
    exit;
}


//获取字符串最后的数字
function getlastnumber($str){
     $arr=  str_split($str);
     $length=count($arr)-1;
     
     for($i=$length;$i>=0;$i--){
         if(is_numeric($arr[$i])){
             $arr1[$i]=$arr[$i];
         }else{
             break;
         }
     }
     ksort($arr1);
     foreach ($arr1 as $key => $value) {
         $number.=$arr1[$key];
     }
     return $number;
}


//传入二级数据.转换成1维数组
function changeArr($arr) {
    if(!empty($arr)){
        foreach ($arr as $key => $value) {
            foreach ($value as $k => $v) {
                $arr[$key]=$v;
            }
        }
    }
    return $arr;
}
//传入二级数据.转换成1维数组(id)
function changeArr1($arr) {
    if(!empty($arr)){
        foreach ($arr as $key => $value) {
                $arr[$key]=$value['id'];
        }
    }
    return $arr;
}
function changeArr3($arr) {

    if(!empty($arr)){
        foreach ($arr as $key => $value) {
                $arr[$key]=$value['app_id'];
        }
    }
    return $arr;
}
//传入分类数据,返回一级分类和二级分类
function changeArr2($arr) {
    if(!empty($arr)){
        foreach ($arr as $key => $value) {
                if($value['pid']==0){
                    $A[]=$value;
                }else{
                    $B[]=$value;
                }
        }
    }
    return array($A,$B);
}
//下面三个函数为获取首字母
function Getszm($str){
    $str= iconv("UTF-8","gb2312", $str);//如果程序是gbk的，此行就要注释掉
    if (preg_match("/^[\x7f-\xff]/", $str))
    {
        $fchar=ord($str{0}); 
        if($fchar>=ord("A") and $fchar<=ord("z") )return strtoupper($str{0});
        $a = $str;
        $val=ord($a{0})*256+ord($a{1})-65536;
        if($val>=-20319 and $val<=-20284)return "A";
        if($val>=-20283 and $val<=-19776)return "B";
        if($val>=-19775 and $val<=-19219)return "C";
        if($val>=-19218 and $val<=-18711)return "D";
        if($val>=-18710 and $val<=-18527)return "E";
        if($val>=-18526 and $val<=-18240)return "F";
        if($val>=-18239 and $val<=-17923)return "G";
        if($val>=-17922 and $val<=-17418)return "H";
        if($val>=-17417 and $val<=-16475)return "J";
        if($val>=-16474 and $val<=-16213)return "K";
        if($val>=-16212 and $val<=-15641)return "L";
        if($val>=-15640 and $val<=-15166)return "M";
        if($val>=-15165 and $val<=-14923)return "N";
        if($val>=-14922 and $val<=-14915)return "O";
        if($val>=-14914 and $val<=-14631)return "P";
        if($val>=-14630 and $val<=-14150)return "Q";
        if($val>=-14149 and $val<=-14091)return "R";
        if($val>=-14090 and $val<=-13319)return "S";
        if($val>=-13318 and $val<=-12839)return "T";
        if($val>=-12838 and $val<=-12557)return "W";
        if($val>=-12556 and $val<=-11848)return "X";
        if($val>=-11847 and $val<=-11056)return "Y";
        if($val>=-11055 and $val<=-10247)return "Z";
    }
    else
    {
        return false;
    }
}
function szm($str){
    $arr=array();
    $szm=array();
    preg_match_all("/./u", $str, $arr);
    for($i=0;$i<count($arr[0]);$i++){
        $szm[$i]=Getszm($arr[0][$i]);
    }
    $szm=implode($szm);
    return $szm;
}
function first($str){
    $str = str_replace(array("_",",","+",";",":",".","\"","、"," ","-","《","》","!","~"), '',$str);
    $arr = preg_split("/([a-zA-Z0-9]+)/", $str, 0, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);  
    for($i=0;$i<count($arr);$i++){
        $chinese = preg_match("/^[\x7f-\xff]+$/",$arr[$i]);
        if($chinese){
            $arr[$i]=szm($arr[$i]); 
        }
    }
    return implode($arr);
}
//获取小数点后两位
function getxsdend2($str) {
    return sprintf("%.2f", $str); 
}

//判断字符串是否在别一个字符串中
function strpos_self($str,$find){
	if(strpos($str,$find)){
		return true;
	}
}




