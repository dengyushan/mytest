<?php
/**
* @Copyright (C) 2015, 
* @Name  Curl.class.php
* @Author  yangw
* @Version  Beta 1.0
* @Date:  2015-3-10
* @Description 网页CURL REQUEST
* @Class List
*/
namespace Common\Library\ORG\Util;
class Curl
{
    var $ch ;
    
    /**
     * @desc 构造
     * @access public
     */
    public function __construct()
    {
    }
function a(){
    echo "123123";
}
    /**
     * @desc 
     * @access public
     */
    public function get($url = "")
    {
       	$ch = curl_init($url); //初始化
    /*	$this_header = array(
            "content-type: application/x-www-form-urlencoded; charset=gbk"
         );
         curl_setopt($ch, CURLOPT_HTTPHEADER, $this_header);*/
         curl_setopt($ch, CURLOPT_HEADER, 0); // 不返回header部分
         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 返回字符串，而非直接输出
         curl_setopt($ch, CURLOPT_USERAGENT, "Dalvik/1.6.0 (Linux; U; Android 4.1.2; DROID RAZR HD Build/9.8.1Q-62_VQW_MR-2)");
         curl_setopt($ch, CURLOPT_REFERER, "-");
         $response = curl_exec($ch);
         $this->_close($ch);
         return $response;
    }
    
    /**
     * @desc 
     * @access public
     */
    public function post($url = "", $curlPost = "")
    {
       	$ch = curl_init($url); //初始化
    /*  $this_header = array(
            "content-type: application/x-www-form-urlencoded; charset=gbk"
	);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $this_header);*/
       	curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
        curl_setopt($ch, CURLOPT_HEADER, 0); // 不返回header部分
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 返回字符串，而非直接输出
        curl_setopt($ch, CURLOPT_USERAGENT, "Dalvik/1.6.0 (Linux; U; Android 4.1.2; DROID RAZR HD Build/9.8.1Q-62_VQW_MR-2)");
        curl_setopt($ch, CURLOPT_REFERER, "-");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
        $response = curl_exec($ch);
        $this->_close($ch);
        return $response;
    }
   

    /**
     * 关闭请求
     * @access public
     */
    private  function _close()
    {
        curl_close($this->ch);
    }
    
    /**
     * @desc close curl
     */
    public function __destruct()
    {
        curl_close($this->ch);
    }
}
