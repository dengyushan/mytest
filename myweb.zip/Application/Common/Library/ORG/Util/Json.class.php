<?php 
/**
 * @Copyright (C) 2015,
 * @Name  Json.class.php
 * @Author  yangw
 * @Version  Beta 1.0
 * @Date:  2015-3-10
 * @Description Json处理类
 * @Class Json
 */
namespace Common\Library\ORG\Util;
class Json {

    /**
     * @desc 生成JSON
     * @param $value
     */
    public function encode($value)
    {
        return $this->_encode($value);
    }

    /**
     * @desc 解析JSON
     * @param string $json
     * @return boolean|null
     */
    public function decode($json)
    {
        switch (strtolower($json)) {
            case 'true':
                return true;
            case 'false':
                return false;
            case 'null':
                return null;
            default:
                return (array) json_decode($json);

        }
    }

    /**
     * @desc JSON
     * @param type $var
     * @return string
     */
    public function _encode($var)
    {
        switch(gettype($var))
        {
            case 'boolean':
                    return $var ? 'true' : 'false';
            case 'NULL':
                    return 'null';
            case 'integer':
                    return (int) $var;
            case 'float':
                    return (float) $var;
            case 'string':
                    return  '"'.$var.'"';
            case 'array':
                    return urldecode(json_encode($this->_urlencode($var)));
            case 'object':
                    $vars = get_object_vars($var);
                    $properties = array_map(array($this, 'name_value'),
                    array_keys($vars),
                    array_values($vars));
                    return urldecode(json_encode($this->_urlencode($properties)));
            default:
                    return 'null';
        }
    }

    /**
     * @desc 将字符串以URL编码返回值
     * @param array $array
     * @return array
     */
    public function _urlencode($array)
    {
        if(is_array($array) && !empty($array))
        {
            foreach($array as $k=>$v)
            {
                if(is_array($v))
                {
                        $array[$k] = $this->_urlencode($v);
                }
                else
                {
                        $array[$k] = $this->preg_utf8($v);
                }
            }
        }
        else
        {
            $array = $this->preg_utf8($array);
        }
        return $array;
    }

    /**
     * @desc 判断是否为字符串
     * @param string $string
     * @return type
     */
    public function preg_utf8($string)
    {
        if(is_string($string))
        {
                return urlencode($string);
        }
        return $string;
    }

    public function name_value($name, $value)
    {
        $encoded_value = $this->_encode($value);
        return $this->_encode(strval($name)) . ':' . $encoded_value;
    }
    
}

