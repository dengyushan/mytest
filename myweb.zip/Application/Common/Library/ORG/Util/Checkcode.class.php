<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Checkcode
 *
 * @author Administrator
 */
namespace Common\Library\ORG\Util;
class Checkcode {
	private $im;
					
	function  show(){
		
		$this->im=  imagecreate(84, 48);
		$gray=  imagecolorallocate($this->im,240, 240, 240);
		
		$black=  imagecolorallocate($this->im, 0, 0, 0);
		$red=  imagecolorallocate($this->im,255,0,0);
		$green=  imagecolorallocate($this->im,9,77,0);
		$blue=  imagecolorallocate($this->im,29,25,202);
		$color=array($red,$green,$blue,$black);
		imagefill($this->im, 0,0, $gray);
		$str="";
		for($i=0;$i<=3;$i++){
			$num=  range(2, 9);
			shuffle($num); 
			$str.=$num[$i];
		//	imagearc($im,  mt_rand(10,70),  mt_rand(5, 20), mt_rand(5, 50), mt_rand(0,5), 0, 270, $color[$i]);
			imagettftext($this->im, 20, mt_rand(-15, 15), ($i-1)*18+25, 30, $color[$i], "./Public/Font/georgiab.ttf", $num[$i]); 
		}
		$verify=  md5($str);
		session('verify', $verify);
		header('Content-type: image/gif');
		imagegif($this->im);
		imagedestroy($this->im);
	}
}

?>
