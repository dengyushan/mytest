<?php

/* * ********
 * 发送邮件 *
 * ******** */
namespace Common\Library\ORG\Util;
class SendMail {
    
    public function SendMail($address, $title, $message) {
        ///  地址 、 标题  、 内容
        ///vendor('PHPMailer.class#PHPMailer');
        require_once("class.phpmailer.php");
  
        $mail = new \PHPMailer();
        // 设置PHPMailer使用SMTP服务器发送Email
        $mail->IsSMTP();

        // 设置邮件的字符编码，若不指定，则为'UTF-8'
        $mail->CharSet = 'UTF-8';

        // 添加收件人地址，可以多次使用来添加多个收件人
        $mail->AddAddress($address);

        // 设置邮件正文
        $mail->Body = $message;

        // 设置邮件头的From字段。
        //$mail->From = C('MAIL_ADDRESS');
        $mail->From = '<B>这是一封测试邮件</B>';

        // 设置发件人名字
        //$mail->FromName = C('MAIL_SENDER');
        $mail->FromName = 'dengyushan';

        // 设置邮件标题
        $mail->Subject = $title.' - '.date("Y-m-d H:i:s");

        // 设置SMTP服务器。
        //$mail->Host = C('MAIL_SMTP');
        $mail->Host = 'smtp.163.com';

        // 设置为“需要验证”
        $mail->SMTPAuth = true;
        //html格式
        $mail->IsHTML(true);
        
       // 'SMTP_USER'   => 'ihtxt@163.com', //SMTP服务器用户名
        
        //'SMTP_PASS'   => 'ihtxt.com', //SMTP服务器密码

        //端口 SSL用的 默认不要
        //$mail->Port = C('MAIL_PORT');
        $mail->Port = 456;
        //SSL加密
        $mail->SMTPSecure = "ssl"; 

        // 设置用户名和密码。  
        //$mail->Username = C('MAIL_LOGINNAME');
        //$mail->Password = C('MAIL_PASSWORD');
		$mail->Username = 'dengyushan251314@163.com';
        $mail->Password = 251314;
        
        // 发送邮件。
        return($mail->Send());
    }

}